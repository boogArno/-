﻿---
title: "MAFIAFOOT"
description: "第一个大亨足球管理游戏"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "mafiafoot.png"
tags: ["Marketplaces","MAFIAFOOT"]
categories: ["nfts"]
nfts: ["Marketplaces"]
blockchain: "Polygon"
website: "https://mafiafoot.com/"
twitter: "https://twitter.com/MafiafootBSC"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/mafiafoot/"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
MAFIAFOOT 是一款为赢得足球俱乐部管理而玩的游戏，女巫集成了强大的 TYCOON 部分。
在发展您的 NFT 卡、赢得比赛和管理俱乐部基础设施的同时创造收入！

黑手党统计
该数据代表被跟踪智能合约的原始链上活动![1500x500](1500x500.jpg)