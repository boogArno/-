---
title: "Magic Land Finance"
description: "Magicland 是一个新兴的可持续去中心化一站式 DeFI 门户，从基于 Arbitrium 和 IoTeX 的单产农业开始."
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "magic-land-finance.png"
tags: ["DeFi","Magic Land Finance"]
categories: ["nfts"]
nfts: ["DeFi"]
blockchain: "IoTeX"
website: "https://iotex.magicland.fi/"
twitter: "https://twitter.com/0xMagicland"
discord: "https://discord.com/invite/gukeP7FZRu"
telegram: ""
github: "https://github.com/magiclandfinance"
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Magicland 是一个新兴的可持续去中心化一站式 DeFI 门户，从基于 Arbitrium 和 IoTeX 的单产农业开始
我们的重点是为支持 Magicland 的公民提供安全的单产农业体验，使其成为 Arbitrum 和 IoTeX 上最神奇的 DeFI 场所。
我们的愿景是在 Arbitrum 和 IoTeX 上创建一个持久的 DeFI 协议，Magicland 及其公民将共同成长，见证 Arbitrum 的崛起，获得 L2 战争的铁椅，IoTeX 不断壮大其独特的实力和用户群![1500x500](1500x500.jpg)