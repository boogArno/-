---
title: "Magician"
description: "Magician 是 Polygon 上的 Metaverse 平台。使用 Defi、NFT 道具和 GameFi 构建"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "magician.png"
tags: ["Exchanges","Magician"]
categories: ["nfts"]
nfts: ["Exchanges"]
blockchain: "Polygon"
website: "https://magicianmetaverse.com/"
twitter: "https://twitter.com/MBTMetaverse"
discord: ""
telegram: ""
github: "https://github.com/MagicBallSwap/core"
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: "https://medium.com/@MBTMetaverse"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
睁开眼睛，你会发现自己置身于一个神奇的世界，魔法球、魔药、水晶和其他未开发的元素是日常的秩序，那些善用它们的人会受到当地居民的尊重并被称为“魔法师”。如果你想在这个世界上生存下去，你需要学习魔法，收集魔法元素和道具。
在这个世界中，Magic Ball Token (MBT) 是核心资产。巫师可以通过 MBT 和 NFT 获得财富和其他神秘力量。魔术师元宇宙建立在多边形大陆上。但是我们魔术师通过许多史前恐龙居住的神奇隧道与另一个世界保持联系。
在这些恐龙的帮助下，我们建立了魔术师的原始魔法世界。双方结成了紧密的联盟。

![1500x500](1500x500.jpg)