---
title: "Madoff's game"
description: "赢得大奖或赚取新玩家的钱."
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "madoff-s-game.png"
tags: ["Gambling","Madoff's game"]
categories: ["nfts"]
nfts: ["Gambling"]
blockchain: "TRON"
website: "https://dappradar.com/"
twitter: "https://twitter.com/madoffsgame"
discord: ""
telegram: "https://t.me/madoffsgame"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: "https://medium.com/@madgames42"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Madoff 的游戏是一个 Tron 赌博 dapp，新玩家试图赢得大奖。输掉的玩家赢新玩家的钱——有了这个游戏，你一定会赢钱！ - 唯一的问题是：多少钱？ -- 倒计时结束时最后买入股票的玩家中奖。 -- 每次有新玩家购买股票时，倒计时会重置，该玩家现在“准时”，累积奖金会增加 40% 的股价。 - 其余的股价在以前的玩家之间分配。

![madoffsgame-dapp-gambling-tron-image2_8d117410d7340de4fa24b8d63cf0d174](madoffsgame-dapp-gambling-tron-image2_8d117410d7340de4fa24b8d63cf0d174.png)