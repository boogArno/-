---
title: "Magic Of Universe"
description: "魔幻宇宙是一款基于加密资产Play To Earn模式的模拟商业+战斗链游戏."
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "magic-of-universe.png"
tags: ["NFT Games","Magic Of Universe"]
categories: ["nfts"]
nfts: ["NFT Games"]
blockchain: "BSC"
website: "https://www.magicofuniverse.games/"
twitter: "https://twitter.com/MOUOfficial2021/"
discord: "https://discord.com/channels/907735300363649094/907735302171418651"
telegram: "https://t.me/MagicofuniverseMY"
github: ""
youtube: ""
twitch: ""
facebook: "https://www.facebook.com/magicofuniverse2021/"
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
魔幻宇宙是一款基于加密资产“Play To Earn”模式的模拟商业+战斗链游戏。前期以BSC公链为基础，后续将开放BSC等多链玩法和跨链应用。游戏以西方魔法学说为主基调，基于区块链NFT技术。以构建一个经济均衡的开放世界为目标，通过用户之间建立幻想、交易、PK战等多种玩法，通过简单公平的方式，让所有玩家通过娴熟的游戏技巧和独特的方式赚取利润和NFT资产。代币经济模式。这是对目前被玩家诟病的单向氪金游戏的告别，开![magicofuniverse-dapp-games-bsc-image1_eabd2c5c0fab2b945d143ae9b75c4a02](magicofuniverse-dapp-games-bsc-image1_eabd2c5c0fab2b945d143ae9b75c4a02.png)创了NFT+Play赚钱的新模式。