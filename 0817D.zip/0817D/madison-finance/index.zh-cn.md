﻿---
title: "Madison Finance"
description: "无许可和非托管 DEX"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "madison-finance.png"
tags: ["Exchanges","Madison Finance"]
categories: ["nfts"]
nfts: ["Exchanges"]
blockchain: "BSC"
website: "https://madisonfinance.org/"
twitter: "https://twitter.com/mdnfinance"
discord: ""
telegram: "https://twitter.com/madisonfinance"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: "https://medium.com/@madisonfinance"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Madison Finance 是一种金融协议，在麦迪逊自动做市商 (AMM) 的支持下改进了无需许可的交易，使用户能够快速、无国界地跨各种链进行交易操作。 Madison Finance 是托管在 Smart Chain 网络上的去中心化交易所，将在主要的去中心化环境下提供基本的交易服务和多种金融服务。麦迪逊的产品包括：跨链 DEX、质押和矿池、NFT Launchpad 和市场。

![madisonfinance-dapp-exchanges-bsc-image1_69e60753f676b99f771aa0f6be2fd6c4](madisonfinance-dapp-exchanges-bsc-image1_69e60753f676b99f771aa0f6be2fd6c4.png)