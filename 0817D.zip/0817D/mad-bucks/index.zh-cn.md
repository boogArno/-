---
title: "MAD Bucks"
description: "Mad Bucks 是一种长期实用型代币，将构成 Mad Meerkat NFT 生态系统的基础."
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "mad-bucks.png"
tags: ["DeFi","MAD Bucks"]
categories: ["nfts"]
nfts: ["DeFi"]
blockchain: "Cronos"
website: "https://mmtreehouse.io/"
twitter: "https://twitter.com/MadMeerkatNFT"
discord: ""
telegram: "https://t.me/MMFcrypto"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: "https://medium.com/@madmeerkat0"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Mad Bucks 是一种长期实用型代币，它将构成 Mad Meerkat NFT 生态系统的基础。 $MAD 代币现在将成为 MMA 世界的治理代币

跨链始终是愿景。将 MM 成长为品牌的梦想，无论您身在何处，都能被认出来，这将永远燃烧疯狂。

疯狂的未来就是现在。你好#多边形。

![madbucks-dapp-defi-cronos-image1_1e7d28d65db13870a9c3ad2025198068](madbucks-dapp-defi-cronos-image1_1e7d28d65db13870a9c3ad2025198068.png)