---
title: "Mad Rabbits Riot Club"
description: "疯兔暴动俱乐部是一个家庭!"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "mad-rabbits-riot-club.png"
tags: ["Collectibles","Mad Rabbits Riot Club"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: "ETH"
website: "https://madrabbits.io/"
twitter: "https://twitter.com/MadRabbitsRC"
discord: "https://discord.com/invite/PhxNbAku89"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/MadRabbitsRiotClub/"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Mad Rabbits Riot Club 是一个令人痛心但（字面上）有益的冒险，进入一个喧闹的 ETH 抢劫、地盘争夺战、秘密集会……以及偶尔入狱的世界。仅存在 7,500 只程序生成的兔子，每个 NFT 的持有者都将能够参与独特的活动，这些活动可能会随着时间的推移不断增加他们疯狂兔子的稀有性。
这不是另一个个人资料图片项目。这是面向未来的、社区驱动的生态系统的开始。我们才刚刚开始。快来加入我们的兔子洞吧。![madrabbitsriotclub-dapp-collectibles-ethereum-image1_e99d3b830c6bfa55f39d70755fdbb692](madrabbitsriotclub-dapp-collectibles-ethereum-image1_e99d3b830c6bfa55f39d70755fdbb692.png)