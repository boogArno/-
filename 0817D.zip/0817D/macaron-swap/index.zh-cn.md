---
title: "Macaron Swap"
description: "加入去中心化交易所和农业平台的未来"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "macaron-swap.png"
tags: ["DeFi","Macaron Swap"]
categories: ["nfts"]
nfts: ["DeFi"]
blockchain: "BSC"
website: "https://macaronswap.finance/"
twitter: "https://twitter.com/macaronswap"
discord: ""
telegram: "https://t.me/macaronswapann"
github: "https://github.com/macaronswap"
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
MacaronSwap 是一个农场和去中心化的跨链交易平台。
MacaronSwap 使用基于币安智能链的自动做市商（AMM）模型。 AMM 意味着虽然您可以在平台上交易数字资产，但没有订单簿可以让您与其他人匹配。相反，您使用流动资金池进行交易。这些池中充满了其他用户的资金。他们将它们存入池中，并获得流动性提供者（或 LP）代币作为回报。他们可以使用这些代币来收回他们的份额，以及部分交易费用。

![macaronswap-dapp-defi-bsc-image1_8a7890af78e0a91a5298ca8d7c63eead](macaronswap-dapp-defi-bsc-image1_8a7890af78e0a91a5298ca8d7c63eead.png)