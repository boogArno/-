---
title: "Maps Project"
description: "地图是冒险家旅程中（伪）随机生成的航路点地名，并附有地图."
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "maps-project.png"
tags: ["Collectibles","Maps Project"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: "ETH"
website: "https://opensea.io/"
twitter: "https://mobile.twitter.com/maps_proj"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
地图是冒险家旅程中（伪）随机生成的航路点地名，并附有地图。所有数据都存储在链上。随心所欲地使用地图，并与您最喜欢的冒险战利品配对。较大的 Loot Project 虚拟世界的一部分。

![mapsproject-dapp-collectibles-ethereum-image1_aa61ec03c92f6deecc0b37eea35d120f](mapsproject-dapp-collectibles-ethereum-image1_aa61ec03c92f6deecc0b37eea35d120f.png)