---
title: "Mail3"
description: "Web3原生通信平台"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "mail3.png"
tags: ["Social","Mail3"]
categories: ["nfts"]
nfts: ["Social"]
blockchain: "ETH"
website: "https://www.producthunt.com/products/mail3"
twitter: "https://mobile.twitter.com/mail3dao"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Mail3 是一种加密原生通信协议，承诺安全、隐私保护和自我主权身份。它还使用户能够捕捉社交联系的价值，并在链上积累数字声誉。

Mail3 Postoffice 是社区拥有的去中心化自治组织，负责管理协议开发、利益相关方之间的协作等。![1500x500](1500x500.png)