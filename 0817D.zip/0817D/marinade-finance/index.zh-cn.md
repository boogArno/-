---
title: "Marinade Finance"
description: "质押 Solana 的最简单方式 - 流动质押"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "marinade-finance.png"
tags: ["DeFi","Marinade Finance"]
categories: ["nfts"]
nfts: ["DeFi"]
blockchain: "Solana"
website: "https://marinade.finance/"
twitter: "https://twitter.com/MarinadeFinance"
discord: "https://discord.com/invite/6EtUf4Euu6"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: "https://medium.com/marinade-finance"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
流动资金，无锁仓
通过使用 Marinade，您可以避免取消抵押期，因此您可以随时自由使用您的资产。
提高网络安全性
我们选择尽可能多的验证者，以使系统更加健壮、安全和去中心化。
像一块木桩一样容易
我们完成所有工作——从管理权益账户到监控验证者和自动重新平衡。![marinadefinance-dapp-defi-solana-image1_eb76cdfed1d259bb328d2cafe2dd55d5](marinadefinance-dapp-defi-solana-image1_eb76cdfed1d259bb328d2cafe2dd55d5.png)