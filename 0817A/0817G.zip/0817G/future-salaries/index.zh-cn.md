---
title: "Future Salaries"
description: "登记工资，捐赠/遗赠普通物品"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "future-salaries.png"
tags: ["DeFi","Future Salaries"]
categories: ["nfts"]
nfts: ["DeFi"]
blockchain: "BSC"
website: "https://vporton.github.io/"
twitter: ""
discord: ""
telegram: ""
github: "https://github.com/vporton/donations"
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
相当于从未来转移资金的数学运算用于根据市场预测的未来软件评估的未来表现，向科学家、自由软件作者或碳会计等公益生产者支付“工资”。我们在经济上刺激搜索引擎所有者根据未来的表现为我们计算工资。共同利益 = 未来，因此从未来转移工资是最公平的分配资金方式。

Future 的平均年薪为 48,958 美元，即每小时 23.54 美元。 Future 每年向底层 10% 的人支付 21,000 美元，而前 10% 的人则支付超过 109,000 美元。未来从事不同工作的员工获得不同的薪水。在企业管理工作中，员工的平均工资为 122,599 美元。

![futuresalaries-dapp-defi-bsc-image1_259e3cd042213402f6ea41ea62afd1e9](futuresalaries-dapp-defi-bsc-image1_259e3cd042213402f6ea41ea62afd1e9.png)
