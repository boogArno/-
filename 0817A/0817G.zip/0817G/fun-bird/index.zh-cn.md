---
title: "Fun Bird"
description: "玩有趣的鸟得到TFN"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "fun-bird.png"
tags: ["Other","Fun Bird"]
categories: ["nfts"]
nfts: ["Other"]
blockchain: "ThunderCore"
website: "https://dappradar.com/"
twitter: "https://twitter.com/tfunfun2"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
玩有趣的小鸟并获得令牌和更多奖励.蓝鸟以其引人注目的羽毛图案和喧闹的个性而闻名，是北美最知名的后院鸟类之一。 但是你知道蓝鸟实际上并不是蓝色的吗？ 许多颜色鲜艳的鸟类，如北方红衣主教，会产生鲜艳的色素，但蓝鸟的羽毛根本不含任何蓝色色素！ 相反，它们含有一种叫做黑色素的棕色色素。 由于一种称为光散射的现象，我们的眼睛只能将羽毛感知为蓝色。

![funbird-dapp-games-thundercore-image1_66e84eb4d71268a624085af59579a2ba](funbird-dapp-games-thundercore-image1_66e84eb4d71268a624085af59579a2ba.png)