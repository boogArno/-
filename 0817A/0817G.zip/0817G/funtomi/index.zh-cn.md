---
title: "Funtomi"
description: "Funtomi Soccer 是币安智能链上基于 NFT 的足球经理游戏。"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "funtomi.png"
tags: ["NFT Games","Funtomi"]
categories: ["nfts"]
nfts: ["NFT Games"]
blockchain: "BSC"
website: "https://funtomi.com/"
twitter: "https://twitter.com/funtomisoccer"
discord: ""
telegram: "https://t.me/funtomisoccer"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://instagram.com/FuntomiSoccer"
reddit: ""
medium: "https://funtomi.medium.com/"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
要参与游戏，必须使用支持 Metamask 的互联网浏览器连接 funtomi.com 网站。
‌
您小队中的玩家将获得独特的 NFT 格式。由您的 BNB 创建。
‌
使用基于 BEP20 的代币 $FUNTO，您可以通过训练您的玩家来提高他们的技能。你可以改进。
‌
每个提高技能的球员都将被邀请参加每周末举行的全国比赛，您可以在国家队中与您的球员一起赚取 $FUNTO。
‌
要扩大您的球员阵容，请查看其他参与者从转会市场出售的球员。
‌
您还可以在转会市场上以 $FUNTO 的价格出售球队中的球员。

![funtomi-dapp-games-bsc-image1_ee96c6f4e7128217d70dc648ffa3b6ef](funtomi-dapp-games-bsc-image1_ee96c6f4e7128217d70dc648ffa3b6ef.png)
