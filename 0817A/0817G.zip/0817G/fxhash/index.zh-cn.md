---
title: "fxhash"
description: "fxhash 是一个在 tezos 区块链上创建和收集生成 NFT 的开放平台"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "fxhash.png"
tags: ["Marketplaces","fxhash"]
categories: ["nfts"]
nfts: ["Marketplaces"]
blockchain: "Tezos"
website: "https://www.fxhash.xyz/"
twitter: "https://twitter.com/fx_hash_"
discord: "https://discord.com/invite/fxhash"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/fx.hash/"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
fxhash 是一个开放平台，艺术家可以在其中铸造存储在 Tezos 区块链上的生成代币。 fxhash 是一个开放平台，没有自上而下的管理。艺术家可以自由上传他们认为有价值的生成艺术作品。策展只通过社区完成。,艺术家

“块”的每个变体都是不同的。这些块是随机放置的，这会导致每个薄荷的声音完全不同的循环。选择随机调色板以及不同的块形状、声音、边框、背景和其他随机特征。这一切都经过精心设计，希望所有变化都会受到喜爱。

![fxhash-dapp-marketplaces-tezos-image2_5ef9041fa8b8d528d9bca31c20e70e3f](fxhash-dapp-marketplaces-tezos-image2_5ef9041fa8b8d528d9bca31c20e70e3f.png)
