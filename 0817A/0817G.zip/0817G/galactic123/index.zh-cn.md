---
title: "GALACTIC123"
description: "Galactic123 一款适用于所有玩家的免费 P2E 老式科幻 MMO 角色扮演游戏 加密或无加密"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "galactic123.png"
tags: ["NFT Games","GALACTIC123"]
categories: ["nfts"]
nfts: ["NFT Games"]
blockchain: "WAX"
website: "https://galactic123.net/"
twitter: "https://twitter.com/hashvirtual"
discord: ""
telegram: "https://t.me/galactic123"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Galactic123 一款适用于所有玩家的老式科幻 MMO 角色扮演游戏 加密或无加密
（任何人都可以玩）
Galactic123 使用 Tron 代币和蜡 NFT'S 帮助打造一个有趣的游戏生态系统
不仅仅是一个游戏冲浪广告和赚取加密奖励。
生态系统中使用的 Tron/Wax 代币

什么是银河 123？
*这是一款科幻角色扮演游戏
* 这是一个免费的网站流量交换（您可以访问自己的网站）
* 这是一个带有各种令牌的水龙头
* Galactic 123 还具有可选的“3D 探索”功能，这是一种带有复古风格图形的 3D 第一人称游戏模式。收集宝藏，杀死怪物，赚取代币（ECX，VRT）。
*上述所有方面都是相互关联的，但同时一切都是可选的；只使用和享受您想要的。

![galactic123-dapp-games-wax-image1_56967bdffc4583a978884e69ff8e8f1b](galactic123-dapp-games-wax-image1_56967bdffc4583a978884e69ff8e8f1b.png)
