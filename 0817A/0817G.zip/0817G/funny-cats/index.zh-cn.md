---
title: "Funny Cats"
description: "在 PlayToEarn 游戏中与我们的猫一起从丛林一路走到城市 - 有趣的猫！"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "funny-cats.png"
tags: ["NFT Games","Funny Cats"]
categories: ["nfts"]
nfts: ["NFT Games"]
blockchain: "WAX"
website: "https://funnycat.io/"
twitter: "https://twitter.com/FunnycatsNFT"
discord: "https://discord.gg/7PYawKvYGQ"
telegram: "https://t.me/funnycatsnft"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
从前，五只勇敢的猫出去寻找冒险。对他们来说，世界比他们通常舒适的巢穴要大得多。到处都是美景、奇异的动物和……宝藏！
在 PlayToEarn 游戏中与我们的猫一起从丛林一路走到城市 - 滑稽猫！

丛林
起初，他们正要探索丛林。一切似乎都习以为常，但猫猫发现，这里也能找到宝物！但是……有没有珠宝数量较多的地方？

村庄
为了到达村庄，猫们不得不长时间训练自己。离开丛林似乎是个疯狂的想法。然而，冒险的渴望更加强烈。在全力以赴的训练之后，猫开始发现这个能给每个人带来无尽印象、财富和机会的大世界。

城市
从村里，他们不得不搬到城里。嘈杂的街道吸引了勇敢的猫。五个人都知道，在小巷子里，在十字路口，甚至在最普通的建筑物里，都隐藏着多少财富。很难想象这座城市有多少事件和印象。他们只需要几个小时来寻宝。

![funnycats-dapp-games-wax-image2_3f48780fc1d751c9092afea62b4471fb](funnycats-dapp-games-wax-image2_3f48780fc1d751c9092afea62b4471fb.png)
