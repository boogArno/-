---
title: "FudFarm"
description: "FUD 农场。 7,777 块农田。"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "fudfarm.png"
tags: ["Collectibles","FudFarm"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: "ETH"
website: "https://dappradar.com/"
twitter: "https://twitter.com/FudFarm"
discord: "https://discord.com/invite/w5z9aKWu"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
在这里质押您的农田，开始赚取 CROP 代币。 这个代币将很快让您在您的虚拟世界农田上收获实际作物，将您美丽的房地产变成农业金矿！ 农场将每天向质押池中的每块土地分配 10 个 $CROP 代币，为期 30 天。 公平发射。 没有预售或团队分配。该团队正在快速构建项目的下一阶段：使用 CROP 开始在您的元界财产上产生真正的收获。 您生产的商品类型将取决于您农场的瓷砖类型。

![fudfarm-dapp-collectibles-ethereum-image2_2c3854f1fd12404beb0aab8bd1ed76c2](fudfarm-dapp-collectibles-ethereum-image2_2c3854f1fd12404beb0aab8bd1ed76c2.png)