---
title: "FusionApes"
description: "Fusion Apes：使用神经网络以融合灵感的艺术风格重新想象猿。"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "fusionapes.png"
tags: ["Collectibles","FusionApes"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: "ETH"
website: "https://www.fusionapes.com/"
twitter: "https://twitter.com/fusionapes"
discord: "https://discord.com/invite/zrcHuuBDc7"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Fusion Apes 简介——以受 Fidenzas 启发的艺术风格重新想象经典猿剪影。使用神经网络的力量单独绘制。在第一个系列中拥有一篇应用深度学习创建风格融合的作品，灵感来自两个具有里程碑意义的 NFT 项目。只有 4,200 只融合猿会被创造出来。加入我们的 Discord 并关注我们的 Twitter，以随时了解我们定于 9 月 3 日美国东部时间晚上 8 点发布的最新消息。

![fusionapes-dapp-collectibles-ethereum-image2_6f51492e45f002f0acfb9aa06cb851aa](fusionapes-dapp-collectibles-ethereum-image2_6f51492e45f002f0acfb9aa06cb851aa.png)
