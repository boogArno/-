---
title: "FTC Official"
description: "如果您正在阅读本文，那么您是为模因而来，为文化而留"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "ftc-official.png"
tags: ["Collectibles","FTC Official"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: "ETH"
website: "https://dappradar.com/"
twitter: "https://www.twitter.com/nftftc"
discord: "https://discord.gg/fortheculture"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
没有路线图，只为文化.历史上第一次免费铸币 + 向铸币者支付 0.01 ETH美国联邦贸易委员会正在寻求阻止虚拟现实巨头 Meta 及其控股股东兼首席执行官马克扎克伯格收购 Within Unlimited 及其流行的虚拟现实专用健身应用程序 Supernatural。 Meta，前身为 Facebook，已经是虚拟现实领域各个层面的关键参与者。 该公司的虚拟现实帝国包括最畅销的设备、领先的应用商店、七位最成功的开发者以及有史以来最畅销的应用之一。 该机构称，Meta 和扎克伯格正计划扩大 Meta 的虚拟现实帝国，企图非法收购一款向用户证明虚拟现实价值的专用健身应用程序。

![ftcofficial-dapp-collectibles-ethereum-image1-500x315_bfa7137c0286a659299ce95a842cda1a](ftcofficial-dapp-collectibles-ethereum-image1-500x315_bfa7137c0286a659299ce95a842cda1a.png)