---
title: "FullBunny.network"
description: "排名第一的众筹 dApp 和股息代币。"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "fullbunny-network.png"
tags: ["Social","FullBunny.network"]
categories: ["nfts"]
nfts: ["Social"]
blockchain: "BSC"
website: "https://dappradar.com/"
twitter: "https://twitter.com/FullBunnyNet"
discord: "https://discord.gg/QA6sDh6wPj"
telegram: "https://t.me/joinchat/OEhwhw5Y0mE2NGM0"
github: ""
youtube: ""
twitch: ""
facebook: "https://www.facebook.com/FullBunny.network/"
instagram: ""
reddit: "https://www.reddit.com/r/FullBunnyNetwork/"
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
如果您想在世界任何地方在 Binance Smart Chain 或 Polygon 上发起众筹活动，那么您来对地方了。
FullBunny.network 将保持一个抗审查、去中心化和去信任的平台。
在 Binance Smart Chain 或 Polygon 上发起活动。
从 4 种类型的广告系列中挑选开始。
原因 - 基于捐赠的筹款活动。
项目 - 众筹，奖励为 ERC-1155 NFT。
CrowdLoaning - 以 ERC-1155 NFT 形式提供贷款的筹款活动。
CrowdEquity - 使用 ERC-20 产品启动 ICO 的简单方法。
以 0% 的费用和 0% 的隐藏费用捐赠给公益事业。
购买奖励、贷款和股权时，将收取 1% 的费用。 DEX 上每笔交易有 1% 的佣金。 您还可以通过持有 Full Bunny 红利代币从该费用池中赚取红利。

![s-l1000](s-l1000.jpg)