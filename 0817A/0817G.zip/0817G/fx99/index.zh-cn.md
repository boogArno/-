---
title: "FX99"
description: "Fx99 完全是一个去中心化的交易所，它在一个功能齐全的基于以太坊的智能合约上运行。"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "fx99.png"
tags: ["High risk","FX99"]
categories: ["nfts"]
nfts: ["High risk"]
blockchain: "ETH"
website: "https://fx99.io/"
twitter: "https://twitter.com/fx99_xcix"
discord: ""
telegram: "https://t.me/fx99io"
github: "https://github.com/Fx99dApp"
youtube: "https://www.youtube.com/channel/UC9Q8sl9MBogltR0FdHwuxYQ"
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Fx99 完全是一个去中心化的交易所，它在一个功能齐全的基于以太坊的智能合约上运行。

Fx99 是一个 dApp 交易所，允许您用以太坊交易 XCIX 代币。 XCIX 代币是具有巧妙转折的 ERC-20 代币：每次其他人购买、出售、再投资和转让代币时，每个 XCIX 持有者都会在以太坊中获得直接收益，然后用户将根据他们的持有量获得特定数量的股息。

![fx99-dapp-exchanges-ethereum-image2_713581cbf3ae7e6af524ef715d9c3fec](fx99-dapp-exchanges-ethereum-image2_713581cbf3ae7e6af524ef715d9c3fec.png)
