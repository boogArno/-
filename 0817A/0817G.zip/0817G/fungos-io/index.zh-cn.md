---
title: "Fungos.io"
description: "每一种真菌都是独一无二的，就像人类的指纹"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "fungos-io.png"
tags: ["Collectibles","Fungos.io"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: "BSC"
website: "https://fungos.io/"
twitter: ""
discord: ""
telegram: ""
github: ""
youtube: "https://www.youtube.com/c/todamateriabrasil/"
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
<p>真菌来自英文中的“fungos”或“fungis”，这是“保存”在树脂中的孢子集合。就像人类的指纹一样，每个 &nbsp;孢子都是独一无二的，这就是它们的特别之处。自从培养它们直到收集到孢子。 &nbsp;并不是所有的真菌都以我们可以储存的方式出生，每 10 个蘑菇只收集大约 2 或 3 个给我们正确的孢子印。 &nbsp;但值得的是，看着他们长大然后永远被放在树脂里是 &nbsp;真正值得的东西。</p>

![fungosio-dapp-collectibles-bsc-image1_a2d29ee542201a891d820bb776887b26](fungosio-dapp-collectibles-bsc-image1_a2d29ee542201a891d820bb776887b26.png)
