---
title: "G-Bots by GAMEE"
description: "进入 G-Bot 虚拟世界"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "g-bots-by-gamee.png"
tags: ["NFT Games","G-Bots by GAMEE"]
categories: ["nfts"]
nfts: ["NFT Games"]
blockchain: "Polygon"
website: "https://www.gamee.com/"
twitter: "https://twitter.com/gameetoken"
discord: "https://discord.com/invite/GHN23sej6Q"
telegram: "https://t.me/gameetoken"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: "https://gamee.medium.com/"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
G-Bots 是基于多边形的 NFT（使用 ERC-721 标准），旨在在新的游戏时代提供终极的 Play & Earn 体验。
玩家将能够升级他们的 NFT、玩游戏、赌注并获得奖励、访问独家内容和福利，或在 G-Bots Metaverse 内的 PvP 战斗中挑战其他玩家。

$ET 为您的 G-Bot 提供燃料，让它们能够繁殖、升级和进化。它们是 G-Bots 的原生代币，可以通过在锦标赛中与它对战来获得。

战斗已经开始。参与这款惊心动魄、闪电般快速的益智游戏，颜色组合和能量提升有助于您的 G-Bot 战胜敌人。

![gbotsbygamee-dapp-games-matic-image3_ea9ec4356220185fb96f04ee6d3a3355](gbotsbygamee-dapp-games-matic-image3_ea9ec4356220185fb96f04ee6d3a3355.png)
