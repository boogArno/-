﻿---
title: "Doge Pound Puppies"
description: "NFT 项目。 10k 独特的#doges 🐶 月球任务🚀"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "doge-pound-puppies.png"
tags: ["Collectibles","Doge Pound Puppies"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: "ETH"
website: "https://thedogepoundnft.com/"
twitter: "https://twitter.com/TheDogePoundNFT"
discord: "https://discord.com/invite/6xEq5wxR6M"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
来自 The Doge Pound 的创造者来自 Doge Pound Puppies。他们很可爱，很可爱，也准备登月了！收集自己一个成年人和一只小狗，在路上你可能会解锁一些特别的东西！Doge Pound NFT，在社区内也称为“OG Doge”，是以太坊区块链上 10,000 个 NFT（Non-Fungible Tokens）的集合。每个 OG Doge 都授予会员专享福利，包括早期访问我们游戏工作室和合作伙伴的新版本、即将推出的 P2E 游戏、会议、游戏活动和独家预售机会。

![dogepoundpuppies-dapp-collectibles-ethereum-image1_23810834b68333a7f402ebfdc22d5c0a](dogepoundpuppies-dapp-collectibles-ethereum-image1_23810834b68333a7f402ebfdc22d5c0a.png)