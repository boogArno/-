﻿---
title: "DoKEN"
description: "使用集成令牌安全扫描器的实时图表交换，为您的项目创建奖励仪表板，并为您的项目打开质押池"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "doken.png"
tags: ["DeFi","DoKEN"]
categories: ["nfts"]
nfts: ["DeFi"]
blockchain: "BSC"
website: "https://doken.exchange/"
twitter: "https://twitter.com/DoKenToken"
discord: ""
telegram: "https://t.me/dokentoken"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
DōKEN 是一种革命性的 meme 代币。让我们与众不同的是，它建立在币安智能链上，比使用以太坊网络买卖便宜 100 倍以上。
DōKEN的梦想是成为人民的信物。改编模因和实用程序用例，我们希望有一天我们可以成为“珍贵的人” 追随这个梦想，DōKEN 有一个很棒的路线图，现在我们已经提供了一些强大的实用程序，即带有实时图表的 Doken Swap，股息用于 Staking 的 Hub 和 Dojo。我们还没有完成，我们有很多实用程序即将推出，例如 DoKENPad (Launchpad)、Token & LP Locker、KYC Audit、移动应用程序等等由于我们是社区驱动的代币，我们很高兴听到任何建议来自社区，为此，请加入我们的电报组放弃你的想法。

![Lr7svFD](Lr7svFD.png)