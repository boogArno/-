---
title: "Fountain Protocol"
description: "喷泉协议"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boodArno"]
featuredImage: "fountain-protocol.png"
tags: ["DeFi","Fountain Protocol"]
categories: ["nfts"]
nfts: ["DeFi"]
blockchain: "Oasis Network"
website: "https://ftp.cash/"
twitter: "https://twitter.com/fountainprot"
discord: "https://discord.com/invite/fdKSBd7zGU"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: "https://medium.com/@fountainprot"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false<p>Fountain Protocol is the first cross-chain lending platform powered by Oasis. The protocol enables users to experience high capital efficiency one-stop management of DeFi assets.</p>
---

Fountain Protocol 是第一个由 Oasis 提供支持的跨链借贷平台。该协议使用户能够体验到高资本效率的 DeFi 资产一站式管理。

Fountain Protocol 是第一个由 Oasis 提供支持的跨链借贷平台。该协议使用户能够体验到高资本效率的 DeFi 资产一站式管理。 Fountain Protocol利用Oasis网络极其高效、低成本的优势，建立了以资金池为核心、多种应用场景的多收益协议。![1080x360](1080x360.jpg)