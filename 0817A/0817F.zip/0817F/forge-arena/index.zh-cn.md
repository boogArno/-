---
title: "Forge Arena"
description: "Forge Arena 是使用 VulcanVerse 中的 Vulcanites 的自动战斗者。在这款奇幻战斗机中让您的 NFT 角色与 AI 或对手对抗。"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boodArno"]
featuredImage: "forge-arena.png"
tags: ["NFT Games","Forge Arena"]
categories: ["nfts"]
nfts: ["NFT Games"]
blockchain: "Vulcan Forged"
website: "https://arena.vulcanforged.com/"
twitter: "https://twitter.com/playforgearena"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Forge Arena 是一款全新的单机游戏，可让您连续对抗四个 AI 对手，或在 PvP 中进行斗智斗勇，让您在争夺竞技场的主导权之战中组建、组合和升级团队。在这场比赛中，胜利不是由抽搐反应决定的，而是由高超的战术决定的。

我们现在处于 alpha 阶段
@PlayForgeArena
 并且测试正在进行中。这种多层自动战斗机使用 Vulcanites
@VulcanVerse
 并将包括@CoddlePets 的龙。任何加入 Vulcan 生态系统的游戏都可以添加他们的角色！![1500x500](1500x500.jpg)