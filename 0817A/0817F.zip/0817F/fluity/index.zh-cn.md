﻿---
title: "Fluity"
description: "BSC 上的去中心化借贷协议。"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boodArno"]
featuredImage: "fluity.png"
tags: ["DeFi","Fluity"]
categories: ["nfts"]
nfts: ["DeFi"]
blockchain: "BSC"
website: "https://fluity.finance/"
twitter: "https://twitter.com/FluityFinance"
discord: "https://discord.gg/etvyP53Sdc"
telegram: "https://t.me/fluity"
github: "https://github.com/fluity-finance"
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Fluity Protocol 是币安智能链上 Liquity 协议的一个友好分支。 Fluity 致力于实现 Liquity 的愿景，即提供无息贷款、高资本效率和抗审查稳定币的去中心化借贷协议。
Fluity 具有与 Liquity 相同的功能（开库借入 FLUSD、赎回、稳定池、质押等），只是来自稳定池和流动性池的 FLTY 奖励将发送到归属合约，而不是直接返回给用户。

![fluity-dapp-defi-bsc-image1_ac3e6abb4e4365083bae80e426ceb6ee](fluity-dapp-defi-bsc-image1_ac3e6abb4e4365083bae80e426ceb6ee.png)