---
title: "FMTLOL"
description: "社交媒体交流"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boodArno"]
featuredImage: "fmtlol.png"
tags: ["Social","FMTLOL"]
categories: ["nfts"]
nfts: ["Social"]
blockchain: "BSC"
website: "https://app.fmt.lol/"
twitter: "https://twitter.com/fmtlol"
discord: "https://discord.gg/DNkStvC7vp"
telegram: "https://t.me/fmtlol"
github: ""
youtube: ""
twitch: ""
facebook: "https://www.facebook.com/fmtlol"
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---

FMTLOL Dapp 用于创建用户活动以增加用户的知名度，通过添加社交帐户链接并允许用户在关注此帐户时获得 FM 令牌。

Follow Me 是基于 DeFi 的社交媒体奖励代币。该令牌允许用户创建他们的露营并增加他们的知名度。

跟我来令牌
社交媒体奖励
开始你的活动，增加你的知名度
推特@fmtlol
官方电报群

![fmtlol-dapp-social-bsc-image1_23130c18f4306b2a9c9358dc11cd9f1b](fmtlol-dapp-social-bsc-image1_23130c18f4306b2a9c9358dc11cd9f1b.png)