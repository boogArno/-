---
title: "Foodcourt Finance"
description: "1# BSC 上的桥接单产农业创新。
我们是 BSC 上的 AMM，为来自其他链（如 KUB、MATIC 等）的原生币桥提供 LP。"
date: 2022-07-31T00:00:00+08:00
lastmod: 2022-07-31T00:00:00+08:00
draft: false
authors: ["Metabd"]
featuredImage: "foodcourt-finance.png"
tags: ["DeFi","Foodcourt Finance"]
categories: ["nfts"]
nfts: ["DeFi"]
blockchain: "BSC"
website: "https://www.foodcourt.finance/"
twitter: "https://twitter.com/foodcourtf"
discord: ""
telegram: "https://t.me/foodcourtofficial"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---

Foodcourt 是币安智能链上领先的创新去中心化交易所（DEX），专注于成为最大的原生 ETH（原生币）交易所。激励用户通过收益农业在 Foodcourt 集中流动性以赚取本国货币 $COUPON。此外，客户可以使用他们赚取的 $COUPON 在我们的美食广场生态系统中使用（详细说明......）美食广场使用 KillSwitch（北桥）标准作为原生硬币，这将有助于解决客户想要跨界时流动性低的问题到其他链，例如 BSC 上的 KillSwitch 标准 kMatic，客户可以通过 LP 购买 kMatic 并使用桥接回到 Matic 链，kMatic 成为真正的 Matic Coin 未来 foodcourt 将列出所有具有 BIP39 钱包标准的原生代币，例如 ETH、Avalance ，Klaytn，heco，ont，fantom，和谐，xDAI。![foodcourtfinance-dapp-defi-bsc-image1_4dd177044076004ab3912905064fc052](foodcourtfinance-dapp-defi-bsc-image1_4dd177044076004ab3912905064fc052.png)