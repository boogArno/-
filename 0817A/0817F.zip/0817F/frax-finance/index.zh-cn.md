---
title: "Frax Finance"
description: "部分稳定币和第一个加密原生 CPI（Frax 价格指数）的发明者。 FRAX 是唯一具有部分支持和部分算法的稳定币"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "frax-finance.png"
tags: ["DeFi","Frax Finance"]
categories: ["nfts"]
nfts: ["DeFi"]
blockchain: ""
website: "https://dappradar.com/"
twitter: "https://twitter.com/fraxfinance"
discord: ""
telegram: "https://t.me/fraxfinance"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Frax 试图成为第一个实现两者设计原则的稳定币协议，以创建高度可扩展、无需信任、极其稳定且意识形态纯正的链上货币。 Frax 协议是一个包含稳定币 Frax (FRAX) 和治理代币 Frax Shares (FXS) 的两个代币系统。 该协议还有一个持有 USDC 抵押品的矿池合约。 可以通过治理添加或删除池。

![fraxfinance-dapp-defi-ethereum-image1_a5aa6a0b9c94012055ea4a1c7934cb71](fraxfinance-dapp-defi-ethereum-image1_a5aa6a0b9c94012055ea4a1c7934cb71.png)