---
title: "Floki Solana Token"
description: "Floki Solana 代币是基于币安智能链构建的第一个 memed 版本的 solana。它是一种超通缩的新系统反鲸鱼代币。"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "floki-solana-token.png"
tags: ["High risk","Floki Solana Token"]
categories: ["nfts"]
nfts: ["High risk"]
blockchain: "BSC"
website: "www.flokisolana.cc"
twitter: "https://twitter.com/flokisolana"
discord: ""
telegram: "https://t.me/flokisolanatoken"
github: "http://github.com/flokisolana"
youtube: ""
twitch: ""
facebook: "https://www.facebook.com/flokisolanatoken"
instagram: "https://www.instagram.com/flokisolanatoken/"
reddit: "https://www.reddit.com/r/FlokiSolanaToken/"
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
币安智能链上的 Floki Solana 是 solana 的 meme 版本，旨在使持有者实现持有的实际目的。它是一种超通缩、反鲸鱼和反地毯的代币，它使用公牛专用机制来确保每个持有者都能获得他们的奖励。作为一个社区，我们致力于确保持有者和用户赚取他们花钱的原因，保持一个健康的社区充满hodlers。

![flokisolanatoken-dapp-defi-bsc-image2_be48b7e0215cd52b3143115774f4a623](flokisolanatoken-dapp-defi-bsc-image2_be48b7e0215cd52b3143115774f4a623.png)