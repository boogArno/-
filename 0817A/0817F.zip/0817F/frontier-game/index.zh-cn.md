﻿---
title: "Frontier Game"
description: "Frontier 是一款 PvP NFT GameFi_ ⚔️"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "frontier-game.png"
tags: ["NFT Games","Frontier Game"]
categories: ["nfts"]
nfts: ["NFT Games"]
blockchain: "ETH"
website: "https://dappradar.com/"
twitter: "https://twitter.com/missingfrontier"
discord: "https://discord.com/invite/5pdAVEcwac"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
100% 自定义 ‍‍ ‍一切都是在我们的自定义智能合约下铸造和生成的。系列一 ‍‍ ‍黑盒系列一已售罄。 我们再也不会卖掉它们了。2,000 KEYS ‍ $DATA Utility Token [ERC-20] 将分发给所有 Frontier NFT 持有者。你是他们中的一员，在这个严酷的新边境中，你是生存、茁壮成长还是死去，都取决于你！ 在新的虚幻引擎 5 中开发 Frontier 正在突破性的虚幻引擎 5 中开发。引擎中引入的改变游戏规则的系统可以释放游戏的全部潜力。 巨大的，完全动态的世界

![frontiergame-dapp-games-ethereum-image2_5bef76639b16ee6fc09ed3d154817eb3](frontiergame-dapp-games-ethereum-image2_5bef76639b16ee6fc09ed3d154817eb3.png)