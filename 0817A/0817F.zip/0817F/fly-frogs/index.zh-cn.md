---
title: "Fly Frogs"
description: "未来是两栖的，ribbit。"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boodArno"]
featuredImage: "fly-frogs.png"
tags: ["Collectibles","Fly Frogs"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: "ETH"
website: "https://flyfrogs.xyz/"
twitter: "https://twitter.com/FlyFrogsNFT"
discord: "https://discord.com/invite/kfp4xftqKM"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Fly Frogs 是 10,000 个随机生成的 NFT 的集合。没有两只青蛙是完全一样的。青蛙由 180 多种手绘资产组成，具有 6 个特征：

  背景 (25)
  皮肤 (23)
  头 (52)
  眼睛 (14)
  嘴巴 (17)
  服装 (56)

![flyfrogs-dapp-collectibles-ethereum-image2_319c534a5b62ddd1dec4692fd146b2e5](flyfrogs-dapp-collectibles-ethereum-image2_319c534a5b62ddd1dec4692fd146b2e5.png)