---
title: "Frag Toss"
description: "经典投币游戏的爆炸性转折"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boodArno"]
featuredImage: "frag-toss.png"
tags: ["Gambling","Frag Toss"]
categories: ["nfts"]
nfts: ["Gambling"]
blockchain: "TRON"
website: "https://fragtoken.io/"
twitter: "https://twitter.com/FragToken"
discord: "https://discord.gg/9KZXg53"
telegram: "https://t.me/fragtoken"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false<p>An explosive twist on the classic coinflip game, just pick your side and toss it up! Mine FragBonds for divs by playing this classic game. Requires $FRAG tokens to play (trc20 token on tron)</p>
---

经典的硬币翻转游戏的爆炸性转折，只需选择你的一边并折腾它！通过玩这款经典游戏，为 div 挖掘 FragBonds。需要 $FRAG 代币才能玩（tron 上的 trc20 代币）

Frag Toss 是硬币翻转的类似加密的演绎。您选择两个的一侧，然后折腾-就是这样！如果您赢了，您将获得 div 的奖金。不过，该游戏需要 $FRAG 代币才能玩。这些代币可以与 ERC-20 兼容，也可以基于 TRON。![Eweb6mYXEAAdTGy](Eweb6mYXEAAdTGy.png)