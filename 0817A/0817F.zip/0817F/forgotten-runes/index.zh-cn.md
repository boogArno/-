---
title: "Forgotten Runes"
description: "The Forgotten Runes Wizard's Cult 是一个协作的传奇故事。 10,000 个独特的 Wizard NFT，在链上完全编码。"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boodArno"]
featuredImage: "forgotten-runes.png"
tags: ["Collectibles","Forgotten Runes"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: "ETH"
website: ""
twitter: "https://twitter.com/forgottenrunes"
discord: "https://discord.com/invite/F7WbxwJuZC"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Forgotten Runes Wizard's Cult 是 10k Wizard NFT 的集合。每个向导都是独一无二的，并且有自己的名字。此外，所有巫师艺术都是在链上完全编码的。
随着我们的邪教为社交媒体和我们独一无二的传说之书贡献艺术、动画、故事、模因和传说，被遗忘的符文世界每天都在增长。
这种去中心化的世界建设方法具有无限的潜力。我们称之为“协作传奇”。大多数参与这个世界构建实验的人都加入了从拥有巫师 NFT 开始的邪教。

Forgotten Runes Wizard's Cult 是 10k Wizard NFT 的集合。每个向导都是独一无二的，并且有自己的名字。此外，所有巫师艺术都是在链上完全编码的。

随着我们的教派为社交媒体和我们独一无二的传说之书贡献艺术、动画、故事、模因和传说，被遗忘的符文世界每天都在增长。

这种去中心化的世界建设方法具有无限的潜力。我们称之为“协作传奇”。大多数参与这个世界构建实验的人都加入了从拥有巫师 NFT 开始的邪教。![forgottenrunes-dapp-collectibles-ethereum-image1_2638adcdec600dced08ee86331debbe9](forgottenrunes-dapp-collectibles-ethereum-image1_2638adcdec600dced08ee86331debbe9.png)