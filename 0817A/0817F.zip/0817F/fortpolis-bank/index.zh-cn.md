﻿---
title: "Fortpolis Bank"
description: "正在寻找一个拥有所有优势 + 无卖出限制、代币实用性和赚取生态系统的游戏的 BusdMachine 分叉？你已经找到了！"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boodArno"]
featuredImage: "fortpolis-bank.png"
tags: ["High risk","Fortpolis Bank"]
categories: ["nfts"]
nfts: ["High risk"]
blockchain: "BSC"
website: "https://www.fortpolis.app/"
twitter: "https://twitter.com/0xFortpolis"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
HTML






第 1 步 - 质押 BUSD 并获得 FORT 代币的每日质押奖励（每存入 100 BUSD 每天 2 个代币）。您可以随时领取您的 $FORT 奖励。您无法取消质押您质押的 BUSD。
第 2 步 - 您的 $FORT 代币有三种选择：您可以将它们出售以换取 BUSD，您可以质押它们以赚取更多的 $FORT 代币（每 100 FORT 质押每天 4 个），或者您可以使用您的 FORT 来玩其他游戏FORTpolis 游戏。
--------------------
$FORT 质押被锁定 7 天。
--------------------
FORT 代币没有销售限制，每次您在其他 Fortpolis 游戏中使用 FORT 时，它们都会返回银行的可用供应量。
术语
▶ 总供应量：可以存在的 $FORT 的最大数量
▶ 流通供应：当前钱包中的 $FORT 代币数量
▶ 可用供应量：（总供应量 - 流通供应量）
▶ $FORT 价格：（总 BUSD 余额 / 可用供应）
▶ Mint $FORT - 当您从铸币中索取 $FORT 时，它会从可用供应中移除并添加到流通供应中
▶ 出售 $FORT - 当您出售 $FORT 时，它会从流通供应中移除并添加到可用供应中![fortpolisbank-dapp-high-risk-bsc-image2_145acc757dac1968bb466d046ca9f94d](\fortpolisbank-dapp-high-risk-bsc-image2_145acc757dac1968bb466d046ca9f94d.png)