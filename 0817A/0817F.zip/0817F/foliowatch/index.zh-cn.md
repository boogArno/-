---
title: "Foliowatch"
description: "投资组合和流动资金池性能观察以及收益农业，完全去中心化。"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boodArno"]
featuredImage: "foliowatch.png"
tags: ["High risk","Foliowatch"]
categories: ["nfts"]
nfts: ["High risk"]
blockchain: "BSC"
website: "https://foliowatch.net/"
twitter: "https://twitter.com/folio__watch?s=09"
discord: ""
telegram: "https://t.me/foliowatch"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Foliowatch 是 Binance Smartchain 上第一个具有 LP 管理的智能 Defi Dashboard。
投资组合和流动资金池性能观察以及收益农业，完全去中心化。
LP 性能观察功能是 FolioWatch Dapp 的一种独特用途，它允许用户在 Binance 智能链上的不同去中心化交易所跟踪和监控他们的流动性汇集代币![1500x500](1500x500.jpg)