﻿---
title: "Flowerpatch"
description: "Flowerpatch 是一款以 aro 为中心的数字农业游戏"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "flowerpatch.png"
tags: ["NFT Games","Flowerpatch"]
categories: ["nfts"]
nfts: ["NFT Games"]
blockchain: "ETH"
website: "https://flowerpatch.app/"
twitter: "https://twitter.com/flowerpatchgame"
discord: "https://discord.gg/mVXMECD"
telegram: "https://t.me/Flowerpatch"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: "https://www.reddit.com/r/flowerpatch"
medium: "https://medium.com/@nugbase"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Flowerpatch 是一款数字农业游戏，以收藏品和备受追捧的 ERC-721 FLOWER 为中心。我们已经消除了在现实世界中种植大麻的劳动密集型责任，并使您能够在舒适的家中或地球上的任何地方实现这一梦想。揭开 Flowerpatch 独一无二的算法染色体搅拌器的魔力，让玩家能够在短时间内传播和创造一种前所未见的大麻表型，直接继承基因构成从它的父母那里。游戏玩家有一个绝佳的机会在个性化的土地上种植他们的花卉，并将它们与附近的其他植物杂交。 Flowerpatch 是一种革命性、协作性的角色扮演体验，非常有趣，包含无穷无尽的惊喜&nbsp;和不同寻常的角色。建立自己的农场，结识其他志同道合的人，并探索不断变化的迷人景观。在一个轻松、雄伟的多人游戏世界中，完全控制一只爱好玩乐的考拉，从而摆脱生活的破坏性压力。

![1500x500](1500x500.jpg)