---
title: "Folks Finance"
description: "领先的资本市场协议
用于建立在 Algorand 区块链之上的借贷"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boodArno"]
featuredImage: "folks-finance.png"
tags: ["DeFi","Folks Finance"]
categories: ["nfts"]
nfts: ["DeFi"]
blockchain: "Algorand"
website: "https://folks.finance/"
twitter: "https://twitter.com/folksfinance"
discord: "https://discord.com/invite/folksfinance"
telegram: "https://t.me/FolksfinanceOfficial"
github: "https://github.com/Folks-Finance"
youtube: ""
twitch: ""
facebook: "https://www.facebook.com/folksfinanceofficial"
instagram: "https://www.instagram.com/folksfinance/"
reddit: "https://www.reddit.com/r/FolksFinance/"
medium: "https://folksfinance.medium.com/"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
什么是大众金融？
Folks Finance 是服务于资本市场的领先协议，建立在 Algorand 区块链之上。该协议以去中心化和无需许可的方式提供借贷服务。通过借贷业务，Folks 用户可以借出他们的加密资产流动性，并立即开始从其资产中获得被动的经济回报。通过借贷操作，用户可以通过将存入的资金锁定为抵押品来请求加密货币贷款。![1500x500](1500x500.jpg)