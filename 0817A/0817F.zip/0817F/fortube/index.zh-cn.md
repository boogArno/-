---
title: "ForTube"
description: "Decentralized Cryptocurrency Bank."
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boodArno"]
featuredImage: "fortube.png"
tags: ["DeFi","ForTube"]
categories: ["nfts"]
nfts: ["DeFi"]
blockchain: ""
website: "https://for.tube/"
twitter: "https://twitter.com/ForTubeFi"
discord: ""
telegram: "https://t.me/ForTubeFi"
github: "https://github.com/thefortube"
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: "https://www.reddit.com/user/"
medium: "https://medium.com/@theforceprotocol/"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---

ForTube 是一种基于流动资金池的借贷协议，任何人都可以通过它提供数字资产来赚取利息或以抵押品借款。它支持广泛的数字资产。借贷利率经过算法调整，以激励和促进资金池中的最大流动性。

该平台为跨平台资产交易、跨链通信、加密资产支持的稳定币保险、代币板保险和链上支付提供解决方案。 Force Protocol 项目是由 Force Protocol Foundation Ltd 开发和管理的去中心化协议层。![fortube-dapp-defi-ethereum-image2-500x315_06972e708b0da6128b99516d6a0e8cc2](fortube-dapp-defi-ethereum-image2-500x315_06972e708b0da6128b99516d6a0e8cc2.png)