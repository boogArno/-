---
title: "Garden Pools"
description: "币安智能链上的去中心化协议。在社区驱动的项目中质押/耕种您的代币以赚取可观的每日收益。"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "garden-pools.png"
tags: ["DeFi","Garden Pools"]
categories: ["nfts"]
nfts: ["DeFi"]
blockchain: "BSC"
website: "https://staking.thegarden.finance/"
twitter: "https://twitter.com/TheGardenCoin"
discord: "https://discord.gg/Z5ZJmDMREv"
telegram: "https://t.me/TheGarden_group"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: "https://www.reddit.com/r/TheGardenCoins/"
medium: "https://medium.com/@TheGardenCoin/introducing-garden-pools-tgc-staking-pool-on-the-garden-project-7eb90ffedcbb"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Garden Pools 是一种去中心化的质押/耕种协议，具有用户友好的界面。该平台提供高收益的LP Staking。
花园池中使用的硬币称为#TGC。
该币还可用于参与 The Garden 生态系统中的其他 Dapp。
The Garden 是币安智能链上的一个生态系统，每个人都可以在一个安全可信的环境中享受最流行的 Defi 项目/游戏，以及透明的无地毯合约。
Defi 游戏
Garden 是一个在各种区块链上分叉流行的 Defi 协议的生态系统。我们将在已经被证明很受欢迎的分叉上进行构建和改进。这些应用程序中的大多数确实具有锁定部分供应的功能，这将非常适合稳定 TGC 的价格并防止发生任何大的抛售。
治理代币
花园币（$TGC）是花园生态系统的治理代币。我们发布的每个新项目都将积极塑造协议的未来。

![gardenpools-dapp-defi-bsc-image1_1456bd2c23d33c9afd7ed48dc7c44741](gardenpools-dapp-defi-bsc-image1_1456bd2c23d33c9afd7ed48dc7c44741.png)
