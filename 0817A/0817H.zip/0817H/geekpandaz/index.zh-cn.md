---
title: "GeekPandaz"
description: "8888 GeekPandaz 来自潘达利亚和流浪岛的冰雹，是人形 Pandaz，热爱大自然和浓烈的啤酒。"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "geekpandaz.png"
tags: ["Collectibles","GeekPandaz"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: "Immutable X"
website: "https://www.geekpandaz.com/"
twitter: "https://twitter.com/GeekPandaz"
discord: "https://discord.com/invite/RJ6J8x82UQ"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
GeekPandaz 是 Immutable X 上 1,500 个独特 NFT 的 Genesis 集合，这是一种提供无气体铸造和交易的第 2 层以太坊解决方案。
每只熊猫都值得一看 - 精心设计，配备配件，随时准备接管 Pandaria 世界

8888 GeekPandaz 来自潘达利亚和流浪岛的冰雹，是人形 Pandaz，热爱大自然和浓烈的啤酒。

![geekpandaz-dapp-collectibles-immutablex-image1_d7d94bed17acf3dd39b821859a330f1a](geekpandaz-dapp-collectibles-immutablex-image1_d7d94bed17acf3dd39b821859a330f1a.png)
