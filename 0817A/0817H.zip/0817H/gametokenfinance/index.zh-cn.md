---
title: "GameTokenFinance"
description: "GME - BSC 上的 Yield Farm 拥有自己的游戏商店。 GME 用于在 gamemarket 的所有游戏平台（pc、psn、xbox、任天堂）上购买游戏的用例。"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "gametokenfinance.png"
tags: ["Marketplaces","GameTokenFinance"]
categories: ["nfts"]
nfts: ["Marketplaces"]
blockchain: "BSC"
website: "http://ww16.gametoken.finance/"
twitter: "https://twitter.com/gametokenfi"
discord: ""
telegram: "https://t.me/gametokenfi"
github: "https://github.com/GameTokenFinance"
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: "https://medium.com/@gametokenfi"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
<p>币安智能链上的收益平台，坚持加密世界的游戏玩家。项目分为gametoken和gamemarket两部分。 Gametoken 是项目的原生代币，人们可以通过网站的收益农场页面进行投资和获利，让人们要么成为纯粹的投资者以获取利润，要么在以后为游戏市场收集更多的 GME。 Gamemarket 是出售游戏 CD 密钥的地方，只接受 GME，这让人们有机会花费他们赚取的 GME 在他们想要的任何平台上购买任何游戏，从而为代币本身创建一个用例。</p>

![gametokenfinance-dapp-marketplaces-bsc-image1_751e04033d89ead4b28017f20d5c0998](gametokenfinance-dapp-marketplaces-bsc-image1_751e04033d89ead4b28017f20d5c0998.png)
