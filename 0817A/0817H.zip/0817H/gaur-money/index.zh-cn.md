---
title: "Gaur Money"
description: "$GAUR 算法代币是快速发展的生态系统的支柱，旨在为 Cronos 网络带来流动性和新的用例。"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "gaur-money.png"
tags: ["DeFi","Gaur Money"]
categories: ["nfts"]
nfts: ["DeFi"]
blockchain: "Cronos"
website: "https://gaur.money/"
twitter: "https://twitter.com/GaurMoney"
discord: "https://discord.gg/5t7paVP6ju"
telegram: "https://t.me/Gaur_money"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
$GAUR 算法代币是快速发展的生态系统的支柱，旨在为 Cronos 网络带来流动性和新的用例。
该协议的底层机制动态调整 $GAUR 供应量，使其价格相对于 $ETH 的价格上涨或下跌。
受 Tomb Finance 及其前身（Basis、bDollar 和 Soup）背后的最初想法的启发，Gaur.Money 是一个多代币协议，由以下三个代币组成：
-Gaur ($GAUR) -Gaur 股票 ($GSHARE) -Gaur 债券 ($GBOND)

![Gaur.4a2e717f](Gaur.4a2e717f.png)
