---
title: "GameXplorer"
description: "带有区块链浏览器和游戏玩家社交媒体的数字游戏商店。"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "gamexplorer.png"
tags: ["Marketplaces","GameXplorer"]
categories: ["nfts"]
nfts: ["Marketplaces"]
blockchain: "Polygon"
website: "https://gamexplorer.io/"
twitter: "https://twitter.com/HashUp_it"
discord: "https://discord.com/invite/ZxwhHb7R9e"
telegram: "https://t.me/HashUpChat"
github: ""
youtube: ""
twitch: ""
facebook: "https://www.facebook.com/HashUpIt"
instagram: ""
reddit: ""
medium: ""
steam: "https://medium.com/@HashUp"
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
<p>该平台的主要功能是能够以 ERC-20 墨盒的形式直接购买游戏。此外，它还充当区块链浏览器（查看最近的交易和用户），并在未来用作玩家和游戏所有者的社区论坛。创建令人惊叹的可自定义配置文件，并为您的游戏收藏感到自豪。了解您朋友的物品并从关注有影响力的人中获得灵感！</p>

![gamexplorer-dapp-games-matic-image2_c2047ec067a1b3da9730ab3bbc827237](gamexplorer-dapp-games-matic-image2_c2047ec067a1b3da9730ab3bbc827237.png)
