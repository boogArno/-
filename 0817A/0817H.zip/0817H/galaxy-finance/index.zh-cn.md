---
title: "Galaxy Finance"
description: "GALAXY FINANCE 是币安智能链上的下一代自动做市商 (AMM)、Staking、Yield Farming、IDO、Lauchpad 和 NFT。 $GLF 是 na"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "galaxy-finance.png"
tags: ["DeFi","Galaxy Finance"]
categories: ["nfts"]
nfts: ["DeFi"]
blockchain: "BSC"
website: "https://galaxyfinance.app/"
twitter: "https://twitter.com/galaxyfinance3"
discord: ""
telegram: "https://t.me/galaxyfinance_group"
github: ""
youtube: "https://www.youtube.com/watch?v=auRvHzaik9k"
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
GALAXY FINANCE 正在通过我们的跨链协议、交易所、钱包和应用程序生态系统为开放金融提供动力，这些生态系统是构建下一代 DeFi 的乐高积木。
GALAXY FINANCE 是币安智能链上的下一代自动做市商 (AMM)、Staking、Yield Farming、IDO、Lauchpad 和 NFT。 $GLF 是原生货币，是 Galaxy 生态系统中平台的主要治理代币。 $GFT 是我们的太阳能监管货币。您可以在 Galaxy Dapp 上进行质押、耕种、添加矿池……并赚取 $GLF 和 $GFT。
GALAXY FINANCE 拥有一支专门的团队，致力于支持和维护整个 GALAXY FINANCE 链中的 defi 产品，他们还将参与营销和新 defi 产品的推出。这将有助于发展其生物圈，同时自发地为社区、项目和用户带来理想的收益。

![galaxyfinance-dapp-defi-bsc-image1_184fa7a86c98685af7e1ffa42b7b8125](galaxyfinance-dapp-defi-bsc-image1_184fa7a86c98685af7e1ffa42b7b8125.webp)
