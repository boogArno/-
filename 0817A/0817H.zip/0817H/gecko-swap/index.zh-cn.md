---
title: "Gecko Swap"
description: "币安智能链上的第一个非营利性收益农场和 AMM。"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "gecko-swap.png"
tags: ["DeFi","Gecko Swap"]
categories: ["nfts"]
nfts: ["DeFi"]
blockchain: "BSC"
website: "https://geckoswap.finance/"
twitter: "https://twitter.com/geckoswap"
discord: ""
telegram: "https://t.me/geckoswap"
github: "https://github.com/geckoswap"
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: "https://medium.com/@geckoswap"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
GeckoSwap 是一个完全去中心化的交易所和收益农场。不会有 GECKO 的预售或早期持有者。实施公平启动，为所有投资者提供公平的加入机会。 GeckoSwap 选择了最重要的代币经济学元素，包括通货紧缩代币，以创建可持续的生态系统和农业体验。确保在奖励、代币实用性和新开发之间保持平衡是 GeckoSwap 的首要任务。
以下是一些已经实施的重要功能：GECKO 农场和游泳池、审计、热带回购、热带税收、分层农业、移除迁移代码、时间锁定（在发布时添加）。

![geckoswap-dapp-defi-bsc-image1_c9db1adef9bd04e91f5732b132f87e6c](geckoswap-dapp-defi-bsc-image1_c9db1adef9bd04e91f5732b132f87e6c.png)
