---
title: "Gaming Arcade"
description: "Gaming Arcade 是一个 web3.0 游戏平台，玩家可以在其中与全球玩家一起玩，并赚取加密货币。"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "gaming-arcade.png"
tags: ["NFT Games","Gaming Arcade"]
categories: ["nfts"]
nfts: ["NFT Games"]
blockchain: "Polygon"
website: "https://gamingarcade.io/"
twitter: "https://twitter.com/GamingArcade_io"
discord: "https://discord.gg/Jb3yN5GTqB"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: "https://www.facebook.com/gamingarcade.io/"
instagram: "https://www.instagram.com/gamingarcade.io/"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
<p>Gaming Arcade 是街机游戏爱好者的平台，可通过在 1VS1 环境下投注加密货币来玩不同的游戏。它还具有创建自定义房间和每周锦标赛等选项。我们已将我们收集的 NFT 作为游戏通行证，如果持有，将帮助玩家获得 100% 的投注金额，如果下注，玩家将获得平台收入和治理的份额。除了游戏平台外，我们还迎合那些希望通过开发和发布现有游戏在区块链上发布游戏的 web2 游戏公司。</p>

![gamingarcade-dapp-games-matic-image1_e91632106de17e7b0097d4c54efd6255](gamingarcade-dapp-games-matic-image1_e91632106de17e7b0097d4c54efd6255.png)
