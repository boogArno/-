---
title: "Gem"
description: "最佳 NFT 聚合器。在所有市场购买 NFT 时节省高达 42% 的 gas。"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "gem.png"
tags: ["Marketplaces","Gem"]
categories: ["nfts"]
nfts: ["Marketplaces"]
blockchain: "ETH"
website: "https://www.gem.xyz/"
twitter: "https://twitter.com/gemxyz"
discord: "https://discord.gg/gemxyz"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
在 Gem，我们正在构建最好的 NFT 聚合器，让您可以从 A 到 XYZ 访问整个 NFT 市场。
在所有市场中找到最优惠的价格
在一次交易中购买多个 NFT
扫地收集地板
使用任何代币（或多个代币）付款
与直接在市场上购买相比，节省大量天然气我们的使命是提供一流的聚合，从而产生市场上最优惠的价格、最大的 NFT 供应和最完整的数据 - 从以太坊区块链开始。

![gem-dapp-marketplaces-ethereum-image2_d461702457a3f2153d882734d39b4db1](gem-dapp-marketplaces-ethereum-image2_d461702457a3f2153d882734d39b4db1.png)
