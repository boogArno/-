---
title: "Gamma"
description: "Gamma 是由比特币区块链保护的创作者和数字收藏家寻找、列出和销售 NFT 的领先市场。"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "gamma.png"
tags: ["Marketplaces","Gamma"]
categories: ["nfts"]
nfts: ["Marketplaces"]
blockchain: "Stacks"
website: "https://gamma.io/"
twitter: "https://twitter.com/trygamma"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Gamma 是由比特币区块链保护的创作者和数字收藏家寻找、列出和销售 NFT 的领先市场。 Gamma 还为创作者提供了一个铸造平台，无需任何代码即可推出他们的 NFT 收藏，以及一个社交平台，旨在成为以 NFT 为中心的世界 web3 社交身份的中心。

![stxnft-dapp-marketplaces-stacks-image1_72b5d484e6abf6b6e605221adf70b30c](stxnft-dapp-marketplaces-stacks-image1_72b5d484e6abf6b6e605221adf70b30c.png)
