---
title: "Gambling Apes Official"
description: "Gambling Ape 所有者在 Metaverse 中共同拥有一个赌场，受邀参加独家聚会和每周比赛，等等！"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "gambling-apes-official.png"
tags: ["Collectibles","Gambling Apes Official"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: "ETH"
website: "https://gamblingapes.com/"
twitter: "https://twitter.com/gamblingapes"
discord: "https://discord.com/invite/gamblingapes"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/gamblingapes/"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
稀有度和规格
Gambling Apes 是由 120 多个特征创建的 7,777 个独特角色的集合。有些特性非常罕见，只出现一次。所有 Gambling Apes 都是定制生成的，在以太坊区块链上注册，并托管在 IFPS 上——这意味着它们永远不会被改变。
铸币厂将于 2021 年 9 月上旬举行（确切日期将很快在我们的 Discord 中公布）。在此活动期间，您可以花费 0,077 ETH 铸造您自己的 Ape。

![gamblingapesofficial-dapp-collectibles-ethereum-image1_1ac1919f3e823b9f17c458db1ee884df](gamblingapesofficial-dapp-collectibles-ethereum-image1_1ac1919f3e823b9f17c458db1ee884df.png)
