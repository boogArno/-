---
title: "Galaxy Blocks"
description: "经典游戏来了！"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "galaxy-blocks.png"
tags: ["NFT Games","Galaxy Blocks"]
categories: ["nfts"]
nfts: ["NFT Games"]
blockchain: "ThunderCore"
website: "https://esports.win4.fun/"
twitter: "https://twitter.com/projectgalaxyhq"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
很久以前，在遥远的银河系中，有块等着你去打破。

NFT

GXBC 正在以太坊区块链上启动 NFT 项目。 GXBC 和 NFT 项目将可供加密社区以及玩我们游戏的 GXBC 用户使用。

创新系统

在我们的 GXBC 区块链世界中，玩我们游戏的人将能够享受 GXBC 的完整文化，它提供奖励、想法，甚至在我们自己的元界中获得新的生活。

元界



跳入我们创建的元宇宙，开始适合自己和未来的新生活方式。

游戏及更多

您可以享受 Galaxy 的游戏，并以任何您想消费的方式使用 GXBC。但“游戏”只是我们搭建的冰山一角。 GXBC 的新数字内容，包括 VR 即将面世。

![galaxy-blocks-games-thundercore-image1_c56939ea4c81f6b231e60210a4627389](galaxy-blocks-games-thundercore-image1_c56939ea4c81f6b231e60210a4627389.png)
