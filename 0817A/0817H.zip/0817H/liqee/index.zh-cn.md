﻿---
title: "Liqee"
description: "用于质押收益代币的借贷协议和用于流动质押市场的统一门户。"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "liqee.png"
tags: ["DeFi","Liqee"]
categories: ["nfts"]
nfts: ["DeFi"]
blockchain: "ETH"
website: "https://liqee.io/"
twitter: "https://twitter.com/liqeeio"
discord: "https://discord.gg/KxYhYPs8"
telegram: "https://t.me/liqee"
github: ""
youtube: "https://www.youtube.com/channel/UCqiHlh0vVzQipmCQsSpjgmw"
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: "https://liqee.medium.com/"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: fals
---

Liqee 是世界上第一个用于流动质押资产（PoS 质押代币、DeFi 质押代币等）的去中心化借贷协议和用于流动质押市场的统一门户（该协议还为 PoS 和采矿设施提供代币化以及跨多个领域的 PoS 验证服务）网络）。

Likee是一个全球免费原创短视频制作和分享平台，拥有优秀的直播。 Likee 将短视频、视频效果和直播流整合到一个易于使用的应用程序中。借助强大的个性化提要和视频效果，您可以轻松找到病毒视频、捕捉完美视频、观看和直播

![1500x500](1500x500.jpg)