---
title: "Gangster Legends"
description: "Fantom 上的 No.1 Gamefi 项目，集游戏、策略和 DAO 于一体。"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "gangster-legends.png"
tags: ["NFT Games","Gangster Legends"]
categories: ["nfts"]
nfts: ["NFT Games"]
blockchain: "Fantom"
website: "https://gl.richcity.app/"
twitter: "https://twitter.com/GL_RichCity"
discord: "https://discord.com/invite/jHnNPxgcVY"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: "https://medium.com/@GangsterLegends"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
GangsterLegends 2.0 版是一个 Social-GameFi 项目。
主要是集体博弈，考验的是利益权衡、相互合作、帮派选择和博弈。
游戏将基于 10 个帮派，对应 10 个协助社区建设的 DAO，而 GangsterLegends 未来的治理将完全由这 10 个 DAO 设计和领导。
这将是一场游戏、KOL、DAO三者相辅相成的生态实验。

![gangsterlegends-dapp-games-fantom-image1_899180c4be75ca80c3c23b3d4b206af7](gangsterlegends-dapp-games-fantom-image1_899180c4be75ca80c3c23b3d4b206af7.png)
