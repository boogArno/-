---
title: "GBOX"
description: "Gbox是为游戏和元界资产打造的多链NFT市场，一个集聚合交易和生态孵化为一体的游戏和元界平台"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "gbox.png"
tags: ["Marketplaces","GBOX"]
categories: ["nfts"]
nfts: ["Marketplaces"]
blockchain: "BSC"
website: "https://app.gbox.space/"
twitter: "https://twitter.com/Gboxspace"
discord: "https://discord.gg/XjXbjdraZU"
telegram: "http://t.me/gbox_official"
github: "https://github.com/gboxspace"
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: "https://gbox-space.medium.com/"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
币安智能中国gamefi用户空投

发现、交易、游戏
Gbox 是为游戏和元界资产构建的多链 NFT 市场

多链支持
支持ETH BSC Polygon FTM等链，随时随地交易。

特色资产
更多区块链游戏和元界优质NFT资产。

交易赚钱
更快更便宜地交易 NFT，赚取挖矿奖励。

发射台
发现并投资全球优秀的区块链游戏。

![index-category-meta.f234590c](index-category-meta.f234590c.png)
