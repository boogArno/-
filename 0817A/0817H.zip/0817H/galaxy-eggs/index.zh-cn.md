---
title: "Galaxy Eggs"
description: "Gal Barkan 制作的 9,999 个银河蛋。"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "galaxy-eggs.png"
tags: ["Collectibles","Galaxy Eggs"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: "ETH"
website: "https://www.galaxy-eggs.com/"
twitter: "https://twitter.com/galaxy_eggs"
discord: "https://discord.com/invite/galaxy-eggs"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
(art)tificial 是一个探索科技与艺术边界的艺术工作室。我们的第一个项目是 Galaxy Eggs——一个由 9,999 个虚拟世界的 Eggs 组成的生成集合，它们存在于以太坊区块链上。我们的艺术总监 Gal Barkan 在过去的 20 年里一直在创作未来主义和科幻艺术——这个系列一方面是一生工作的高潮，也是参与创作的新篇章的开始元节。

路线图 1
Galaxy Eggs 艺术家 Gal Barkan 收藏展。

20 名幸运的随机 Galaxy Egg 持有者将获得一张 10k 分辨率的印刷版海报，海报由我们的艺术总监 Gal Barkan 直接寄到他们的家中。

Galaxy Eggs Merch Store - 我们将与服装公司合作，为所有 Galaxy Eggs 持有者生产独家商品和服装。

向鸡蛋持有者空投一件艺术品。

Galaxy Warriors - 启动 Galaxy Metaverse 的第二阶段。

![galaxyeggs-dapp-collectibles-ethereum-image2_769566aa898005f513d434757283cdf6](galaxyeggs-dapp-collectibles-ethereum-image2_769566aa898005f513d434757283cdf6.png)
