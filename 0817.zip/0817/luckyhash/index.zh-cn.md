---
title: "LuckyHash"
description: "基于区块哈希的有趣公平的迷你赌场游戏."
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "luckyhash.png"
tags: ["Gambling","LuckyHash"]
categories: ["nfts"]
nfts: ["Gambling"]
blockchain: ""
website: "https://luckyhash.money/"
twitter: "https://twitter.com/luckyhashgame"
discord: ""
telegram: "https://t.me/luckyhashofficial"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
有趣和公平的赌场游戏
LuckyHash 是一种以区块哈希序列的字符为结果的赌场游戏。目前已经发布了5款游戏，更多游戏将陆续发布。
玩家下注时，合约会自动支付上一次下注的奖励；或者玩家可以点击“PENDING”继续手动支付奖励。
如果合约余额不足以结算当前投注，则将记录此未支付金额。当合约余额足以支付时，未支付的部分将与下一次赌注一起支付。

![luckybee-dapp-gambling-bsc-image1_74dd249bf2b6bbd46afdd8658e2ea94b](luckybee-dapp-gambling-bsc-image1_74dd249bf2b6bbd46afdd8658e2ea94b.png)