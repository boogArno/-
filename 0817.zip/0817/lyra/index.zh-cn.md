---
title: "Lyra"
description: "用于交易期权和自动流动性提供的协议."
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "lyra.png"
tags: ["Exchanges","Lyra"]
categories: ["nfts"]
nfts: ["Exchanges"]
blockchain: "Optimism"
website: "https://www.lyra.finance/"
twitter: "https://twitter.com/lyrafinance"
discord: "https://discord.com/invite/P49mj6UbmC"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
用于交易期权和自动提供流动性的协议。

Lyra 是一种基于以太坊的交易期权开放协议。 Lyra 允许交易者买卖使用第一个基于市场的、倾斜调整的定价模型准确定价的期权。 Lyra 还量化了流动性提供者所产生的风险并积极对冲它们，鼓励更多的流动性进入协议。

![lyra-dapp-exchanges-optimism-image2_8f73f1ea7df642fb2db0f883541f9a2b](lyra-dapp-exchanges-optimism-image2_8f73f1ea7df642fb2db0f883541f9a2b.png)