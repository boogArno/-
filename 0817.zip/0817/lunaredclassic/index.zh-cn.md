---
title: "LunaRedClassic"
description: "Luna Red Classic $LRC 是币安智能链上全新的反射协议。该合同将具有独特的功能，将是同类合同中的第一个"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "lunaredclassic.png"
tags: ["DeFi","LunaRedClassic"]
categories: ["nfts"]
nfts: ["DeFi"]
blockchain: "BSC"
website: "https://lunaredclassic.digital/"
twitter: "https://twitter.com/LunaRedClassic"
discord: ""
telegram: "https://t.me/lunaredclassic"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Luna Red Classic $LRC 是币安智能链上的全新反射协议。该合约将具有独特的功能，并且将是同类合约中第一个向持有人介绍绝对零税并且具有通货紧缩性的合约。

LunaRedClassic 统计数据
该数据代表被跟踪智能合约的原始链上活动

![1500x500](1500x500.jpg)