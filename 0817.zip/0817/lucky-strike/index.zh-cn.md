---
title: "Lucky Strike"
description: "赌博而不赌博。投资。玩。赢."
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "lucky-strike.png"
tags: ["Gambling","Lucky Strike"]
categories: ["nfts"]
nfts: ["Gambling"]
blockchain: "ETH"
website: "https://lucky-strike.io/"
twitter: "https://twitter.com/the_luckystrike"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
赌博而不赌博。投资。玩。赢。

幸运罢工统计
该数据代表被跟踪智能合约的原始链上活动
Dapp 用户图表
交易
Dapp 交易图表
体积
$0
Dapp 交易量图表
平衡
6.79 万美元
3.53 以太币
0.869%
Dapp 余额图表

![luckystrike-dapp-gambling-eth-image2_62c5229deba82423901df26838434b5a](luckystrike-dapp-gambling-eth-image2_62c5229deba82423901df26838434b5a.png)