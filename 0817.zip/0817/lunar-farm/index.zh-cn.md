---
title: "Lunar Farm"
description: "一个独特而美丽的农场游戏！
正在开发中!"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "lunar-farm.png"
tags: ["NFT Games","Lunar Farm"]
categories: ["nfts"]
nfts: ["NFT Games"]
blockchain: "Polygon"
website: "https://lunarfarm.net/"
twitter: "https://twitter.com/LunarFarm"
discord: "https://discord.gg/gKu7vrK4p6"
telegram: "https://t.me/lunarfarmofcglobalchat"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
照顾你的农场并获得更多资源
在月球农场，你是一个月球人，最终来到地球上获取资源，因为在你的星球上它们用完了。地球是一个由自然环境组成的世界，您必须在其中收集大量资源并用这些资源建立您的农场。
您的 Lunar（您的化身）工作得越多越好，您将获得越多的资源，这将允许您通过将这些资源出售给其他 Lunars 并将您的游戏内资源兑换成我们的原生代币 $ 来获得我们的 $LFC 治理代币L

![1500x500](1500x500.jpg)CASH。