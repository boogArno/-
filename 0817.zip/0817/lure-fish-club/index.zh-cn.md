---
title: "Lure Fish Club"
description: "带有 NFT 鱼设备和代币化奖励的在线诱鱼俱乐部。第一条在 EVM 链上赢得游戏的鱼."
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "lure-fish-club.png"
tags: ["NFT Games","Lure Fish Club"]
categories: ["nfts"]
nfts: ["NFT Games"]
blockchain: "BSC"
website: "https://lure.game/"
twitter: "https://twitter.com/LureFishClub"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
第一款基于EVM Chain的Web3.0钓鱼游戏。
在 Beta 轮中自由发挥
诱鱼俱乐部
又名 L.F.C 或 L.F 俱乐部

  钓鱼竿可用于钓鱼、制作和升级。
  宝箱和钓鱼竿是 NFT，可在 NFT 市场上交易。
  钻石是治理代币，黄金是游戏代币，都可以在二级市场交易。

![lurefishclub-dapp-games-bsc-image1_fd929a8040f131b5e11134029e0b6805](lurefishclub-dapp-games-bsc-image1_fd929a8040f131b5e11134029e0b6805.png)