---
title: "MAX PAIN AND FRENS BY XCOPY"
description: "MAX PAIN AND FRENS 是艺术家 XCOPY 制作的以太坊区块链上的 NFT 收藏"
date: 2022-08-18T00:00:00+08:00
lastmod: 2022-08-18T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "max-pain-and-frens-by-xcopy.png"
tags: ["Collectibles","MAX PAIN AND FRENS BY XCOPY"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: "ETH"
website: "https://opensea.io/"
twitter: "https://twitter.com/XCOPYART"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Max Pain and Frens 是OG NFT 艺术家 @XCOPYART 在 Nifty Gateway 上推出的多件艺术品的集合。下降包括公开版、两次排名拍卖、一幅绘画和两个级别的刻录以赎回艺术品。开放版作品名为“Max Pain”，面向所有人开放，售出 7,394 个版本。

MAX PAIN AND FRENS 是艺术家 XCOPY 制作的以太坊区块链上的 NFT 收藏

我汇总了所有人的数据
 集合到一个仪表板中，您可以在其中跟踪：

- 所有系列的二次销售

- 按版本类型的收藏家藏品

- 版本特定数据

  ![maxpainandfrensbyxcopy-dapp-collectibles-ethereum-image1_48069f672ac2d700d12117c50a133f54](maxpainandfrensbyxcopy-dapp-collectibles-ethereum-image1_48069f672ac2d700d12117c50a133f54.png)