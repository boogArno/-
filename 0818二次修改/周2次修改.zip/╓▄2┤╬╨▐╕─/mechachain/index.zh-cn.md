---
title: "Mechachain"
description: "🤖玩游戏并赚取游戏🤖
 机甲飞行员可能是你的下一份工作"
date: 2022-08-18T00:00:00+08:00
lastmod: 2022-08-18T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "mechachain.png"
tags: ["NFT Games","Mechachain"]
categories: ["nfts"]
nfts: ["NFT Games"]
blockchain: "Polygon"
website: "https://mechachain.io/"
twitter: "https://twitter.com/mechachain"
discord: ""
telegram: "https://t.me/mechachain"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
2219 年出现——奇点是技术进步超越人类理解的理论转折点，被两个人工智能紧紧抓住。
这两种人工智能的兴起和随之而来的快速技术进步导致了两个对立的超级大国的形成，两者都将机器置于其政府和发展的核心：Hêmérê 的技术民主和 MR-GL-201 的算法。 ，这些新国家的社会和经济表现如此巨大，以至于周围的国家和人民很快加入了他们的行列，在几年内有效地将几乎所有人类划分为两个地缘政治集团。

![mechachain-dapp-games-matic-image1_ce5e7c6cbeca7025d2ed7eb78d2a6a69](mechachain-dapp-games-matic-image1_ce5e7c6cbeca7025d2ed7eb78d2a6a69.png)