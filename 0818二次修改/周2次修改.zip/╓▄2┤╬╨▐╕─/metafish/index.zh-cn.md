---
title: "METAFISH"
description: "MetaFish 是 BSC 上第一个推荐游戏赚取元界 NFT 游戏"
date: 2022-08-18T00:00:00+08:00
lastmod: 2022-08-18T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "metafish.png"
tags: ["NFT Games","METAFISH"]
categories: ["nfts"]
nfts: ["NFT Games"]
blockchain: "BSC"
website: "https://app.metafish.io/"
twitter: "https://twitter.com/metafish_bsc"
discord: ""
telegram: "https://t.me/metafish_ann"
github: "https://github.com/MetafishNFT"
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
MetaFish 是 BSC 上第一个推荐游戏赚取 Metaverse NFT 游戏，其灵感来自名为 Play Together 的流行游戏，在该游戏中，用户扮演渔民的角色，他们的钓竿作为有价值和可销售的 NFT 资产.

MetaFish是一个巨大的数字世界，用户在其中扮演渔民的角色，他们的竹竿作为有价值和可销售的nft资产

渔民可以在商店购买鱼竿或到鱼市场兑换，在钓竿破损前修复，参加钓鱼比赛

渔民可以使用META创建自己的团队FISH推荐系统，他们招募对的渔民越多，他们获得的钓鱼奖励就越多。

![metafishtoken-dapp-games-bsc-image1_e8228d312a097805a2ff9b83432262cf](metafishtoken-dapp-games-bsc-image1_e8228d312a097805a2ff9b83432262cf.png)