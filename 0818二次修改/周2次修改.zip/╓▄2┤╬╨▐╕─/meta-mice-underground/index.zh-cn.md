---
title: "Meta Mice Underground"
description: "Meta Mice Underground 是 4,000 个手绘/生成的 NFT 的集合，它们位于以太坊区块链上，为持有者提供大量实用程序."
date: 2022-08-18T00:00:00+08:00
lastmod: 2022-08-18T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "meta-mice-underground.png"
tags: ["Collectibles","Meta Mice Underground"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: "ETH"
website: "https://metamiceunderground.com/"
twitter: "https://twitter.com/MetaMiceUG"
discord: "https://discord.gg/hvu3MBeTjN"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://instagram.com/MetaMiceUG"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
什么是 Meta Mice Underground ？
Meta Mice Underground 是 4,000 个手绘/生成的 NFT 的集合，它们位于以太坊区块链上，为持有者提供大量实用程序。创始人来自美国，并且完全被人盯上了。每个 MMU 持有者都将获得 BITCOIN 和许多其他福利。

来自美国的 Doxxed 团队 

持有人的大量公用事业 

被动收入来源 

BTC在持有者之间的分配 

生病的艺术 

慈善机构 

社区钱包和 DAO 

由强大的社区支持 

具有 5-6 年计划的长期愿景，

![metamiceunderground-dapp-collectibles-ethereum-image1_9ebb4e0ed831e2386825bce88850583c](metamiceunderground-dapp-collectibles-ethereum-image1_9ebb4e0ed831e2386825bce88850583c.png)