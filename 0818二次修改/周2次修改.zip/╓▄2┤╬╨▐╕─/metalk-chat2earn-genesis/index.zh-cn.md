---
title: "Metalk Chat2Earn Genesis"
description: "Dialoger 预售现已上线
Stake a Dialoger are able to Mint 1 Metalk Chat2Earn"
date: 2022-08-18T00:00:00+08:00
lastmod: 2022-08-18T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "metalk-chat2earn-genesis.png"
tags: ["Collectibles","Metalk Chat2Earn Genesis"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: "ETH"
website: "https://metalkdao.com/"
twitter: "https://www.twitter.com/Metalk_DAO"
discord: "https://discord.gg/metalk-dao"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: "https://www.medium.com/@Metalk_DAO"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Dialoger 预售现已上线 Stake a Dialoger are able to Mint 1 Metalk Chat2Ear

Dialoger是Metalk Kingdom中唯一的Genesis Noble成员。 Dialoger 用户将有幸在 Metalk 上拥有独特的贵族勋章。贵族勋章是用户在虚拟世界中表达身份的最佳方式。此外，Dialoger持有者还享有优先铸币权、空投等各种生态特权。#Metalk #Chat2Earn 经济模式的可持续性在 Metalk 发展之初尤其重要，它是一个广受欢迎的产品，对加密社区来说“有趣”和“有用”。

![metalkchat2earngenesis-dapp-collectibles-ethereum-image1_2abeb2beadf16387d88f7bb942729bb5](metalkchat2earngenesis-dapp-collectibles-ethereum-image1_2abeb2beadf16387d88f7bb942729bb5.png)