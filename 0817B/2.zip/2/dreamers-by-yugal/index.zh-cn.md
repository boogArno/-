---
title: "Dreamers by Yugal"
description: "由数字艺术家 Yugal Odhrani 指导的艺术。

在该系列的生命周期中，只有 44 位梦想家。"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "dreamers-by-yugal.png"
tags: ["Collectibles","Dreamers by Yugal"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: "ETH"
website: "https://opensea.io"
twitter: "https://twitter.com/yvgal"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---

Dreamers 是一个基于时尚与技术之间旅程的系列。一件简单的衣服，可以解决复杂的全球问题，或在我们生活的反乌托邦中生存。重新构想一个我们可以探索新思想和新技术的世界。由数字艺术家 Yugal Odhrani 指导的艺术。在该系列的生命周期中，只有 44 位梦想家。

![dreamersbyyugal-dapp-collectibles-ethereum-image2_4bde4ba916b71bac4dc7898cee341ae4](dreamersbyyugal-dapp-collectibles-ethereum-image2_4bde4ba916b71bac4dc7898cee341ae4.png)