---
title: "DrakeSwap"
description: "DrakeSwap 是币安智能链上的一个收益农业项目"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "drakeswap.png"
tags: ["DeFi","DrakeSwap"]
categories: ["nfts"]
nfts: ["DeFi"]
blockchain: "BSC"
website: "https://drakeswap.com/"
twitter: "https://twitter.com/drakeswapcom"
discord: ""
telegram: "https://t.me/drakeswap"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
DrakeSwap 是币安智能链（BSC）上的去中心化 AMM（自动做市商）协议。
DUCK & SWAN 代币是平台的原生 BEP-20 治理代币。用户可以通过在 DrakeSwap 上提供流动性来赚取 DUCK 代币，质押的 DUCK 可以赚取 SWAN。为了在社交媒体上向加密资产的贡献者致敬，DeGate 提供了以优惠价格购买 DG 代币的早期机会。
1000 万个 DG 代币，0.005 美元

![drakeswap-dapp-defi-bsc-image2-500x315_1ae448e43182007c0b8164c4a1a65fdb](drakeswap-dapp-defi-bsc-image2-500x315_1ae448e43182007c0b8164c4a1a65fdb.png)

