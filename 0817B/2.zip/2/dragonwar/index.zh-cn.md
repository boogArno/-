---
title: "DragonWAR"
description: "龙族与人族两大种族交战，天地如血肉一般颤抖。我没有更多地看到战斗的世界"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "dragonwar.png"
tags: ["High risk","DragonWAR"]
categories: ["nfts"]
nfts: ["High risk"]
blockchain: "BSC"
website: "https://sale.dragonwar.org/"
twitter: "https://twitter.com/DragonWarDRW"
discord: ""
telegram: "https://t.me/dragonwarnews"
github: ""
youtube: "https://www.youtube.com/channel/UCzoPmnzVGtuXkf9yG_UNZqg"
twitch: ""
facebook: "http://www.facebook.com/groups/dragonwarsgo/"
instagram: "https://www.instagram.com/dragonwarorg/"
reddit: "https://www.reddit.com/user/DRW_DragonWAR/comments/rjk6vd/welcome_to_the_dragonwar_best_blockchain_dragon/?utm_source=share&utm_medium=ios_app&utm_name=iossmf"
medium: "https://medium.com/@Dragonwarorg"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
龙友们好！我们决定创建一个官方电报频道，专门用于有关我们项目#DRAGONWAR 的新闻。订阅并打开通知，以免错过重要且最重要的有利可图的项目新闻！基于智能合约的 Dapp，由币安智能链提供支持，覆盖游戏的整个生态系统。系统中超过250,000个与游戏货币相关的独特物品，

龙族与人族两大种族交战，天地如血肉一般颤抖。而我并没有看到更可怕的战斗世界，也不知道前方等待着他的是什么。但那是后来，起初有历史......

DragonWar 是同类游戏中第一款拥有如此大宇宙的游戏

![dragonwar-dapp-high-risk-bsc-image1-500x315_d67fc5e2c8c4fe2ee671b8347434171d](dragonwar-dapp-high-risk-bsc-image1-500x315_d67fc5e2c8c4fe2ee671b8347434171d.png)