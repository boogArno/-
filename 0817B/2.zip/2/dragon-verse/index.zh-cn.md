---
title: "Dragon Verse"
description: "Dragon Verse 是一款即将推出的 PvP/PvE 类型的 Play-to-earn 游戏，建立在 Binance Smart Chain 上，以利用低费用和快速交易速度。"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "dragon-verse.png"
tags: ["NFT Games","Dragon Verse"]
categories: ["nfts"]
nfts: ["NFT Games"]
blockchain: "BSC"
website: "https://dragonverse.finance/"
twitter: "https://twitter.com/Dragonverse_OA"
discord: ""
telegram: "https://t.me/Dragonverse_Official"
github: ""
youtube: "https://www.youtube.com/channel/UCo0vTv47JEf6rdbqQHT2Row"
twitch: ""
facebook: ""
instagram: ""
reddit: "https://www.reddit.com/user/Dragon-Verse"
medium: "https://medium.com/@dragonverse"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Dragon Verse 是一款即将推出的 PvP/PvE 类型的 Play-to-earn 游戏，建立在 Binance Smart Chain 之上，以利用低费用、快速交易速度和庞大的用户群。为你的龙宠准备好所有武器，集结力量与黑魔王和其他玩家战斗！
Dragon Verse 旨在专注于 NFT Marketplace 系统和 Farming，玩家和 DRV 社区可以在这里交易配件并将他们的龙宠物提升到更高的水平。龙宠越强，在交易市场上的价值就越高。让我们玩一个简单、有趣、轻松的游戏，赚取真金白银！
从一开始，Dragon Metaverse 就致力于为 Metaverse 世界开发长期资产，我们正在将您所有的 NFT 转移到虚拟世界中。未来，您可以使用您的 NFT 来获得稀有配件并获得更多利润。

![dragonverse-dapp-games-bsc-image1-500x315_75ed1be850fa996b8b03bc59db9482ca](dragonverse-dapp-games-bsc-image1-500x315_75ed1be850fa996b8b03bc59db9482ca.png)