---
title: "DragonBall Finance"
description: "BSC 网络上的多合一 DeFi 平台"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "dragonball-finance.png"
tags: ["DeFi","DragonBall Finance"]
categories: ["nfts"]
nfts: ["DeFi"]
blockchain: "BSC"
website: "http://ww1.dragonballfinance.org"
twitter: "https://twitter.com/dragonballdefi"
discord: ""
telegram: "https://t.me/dragonballfinance_org"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: "https://dragonballfinance.medium.com"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
DragonBallFinance 是币安智能链网络上第一个完全去中心化、自给自足的一体化 defi 平台，在当前无聊的美食名称 defi 世界中带来了龙珠主题。
DragonBallFinance 将实施多种产品和机制，即使从长远来看，也能确保项目的可持续性。
DragonBallFinance 回购燃烧功能：
质押时将收取 3% 的保证金。
取消质押时将收取2％的提款费。
费用明细
50% 将用于每周烧伤
50%为项目的产品资金。
5% 的铸造代币用于应急和发展基金

![60823d250564812379a9bad1_hGiv_CTa5kRyehrHYdtxjYkuYuYzYv-JWfuvVUuMVnRpiHB65aTTYSs8NvrMBs095JO2ClfPoTKFCouN-JO9Jd4ufFIwUGwvMQYx7utfqiV-ebFU1RpHMLOrLp17w-Gn0Mv6VTCO](60823d250564812379a9bad1_hGiv_CTa5kRyehrHYdtxjYkuYuYzYv-JWfuvVUuMVnRpiHB65aTTYSs8NvrMBs095JO2ClfPoTKFCouN-JO9Jd4ufFIwUGwvMQYx7utfqiV-ebFU1RpHMLOrLp17w-Gn0Mv6VTCO.png)