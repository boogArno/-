---
title: "Dragon Kart"
description: "Dragon Kart 是第一款由社区启发、建造和拥有的基于 3D 技能的赛车对战游戏"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "dragon-kart.png"
tags: ["NFT Games","Dragon Kart"]
categories: ["nfts"]
nfts: ["NFT Games"]
blockchain: "BSC"
website: "https://dragonkart.com"
twitter: "https://twitter.com/Dragonkartcom"
discord: ""
telegram: "https://t.me/dragonkartofficial"
github: ""
youtube: "https://www.youtube.com/channel/UCpOkVWzOh8K0tfyn305SFlA"
twitch: ""
facebook: "https://www.facebook.com/DragonKartCom/"
instagram: ""
reddit: ""
medium: "https://medium.com/@DragonKartcom"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Dragon Kart 是一款建立在区块链平台上的 3D 赛车电竞游戏，游戏中的角色取材于越南知名艺术家 Thang Fly 的皮卡龙系列。玩家可以参加戏剧性的比赛，并利用他们卓越的驾驶技术从来之不易的胜利中获得各种奖励和代币。第一款由社区启发、建造和拥有的基于技能的 3D 赛车战斗游戏。
$KART 是一种功能性的多用途代币，将用作 Dragon Kart 参与者之间以去中心化的方式进行交换的媒介。

![dragonkart-dapp-games-bsc-image1-500x315_2e8fa8a847f9ad311bfd5e9b858c0b2a](dragonkart-dapp-games-bsc-image1-500x315_2e8fa8a847f9ad311bfd5e9b858c0b2a.png)

