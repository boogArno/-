---
title: "DragonBallSwap"
description: "DragonBallSwap 是币安智能链上最新一代的 Yield Farm 和 AMM。 LavaCake Finance 使用许多独特的机制。"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "dragonballswap.png"
tags: ["DeFi","DragonBallSwap"]
categories: ["nfts"]
nfts: ["DeFi"]
blockchain: "BSC"
website: "https://www.dragonball.app"
twitter: "https://twitter.com/DragonBallSwap"
discord: ""
telegram: "https://t.me/EN_DragonBallSwap"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: "https://dragonballswap.medium.com/"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
DragonBallSwap 是币安智能链上最新一代的收益农场和 AMM。该项目使用独特的机制，例如：自动燃烧机制、自动流动性、反鲸鱼、丰收锁定等。
我们的愿景是成为领先的跨链混合去中心化交易所（DEX）。

![dragonballswap-dapp-defi-bsc-image1-500x315_ba8abf1f3da392d9b8bf0b7b3046fbba](dragonballswap-dapp-defi-bsc-image1-500x315_ba8abf1f3da392d9b8bf0b7b3046fbba.png)