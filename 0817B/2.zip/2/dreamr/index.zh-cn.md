---
title: "Dreamr"
description: "Dreamr 是一款与 web3 集成的混合移动应用程序，供人们追求梦想。 $DMR 代币持有者获得 Dreamr+ 并参与平台治理"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "dreamr.png"
tags: ["Social","Dreamr"]
categories: ["nfts"]
nfts: ["Social"]
blockchain: ""
website: "https://www.dreamr.app"
twitter: "https://twitter.com/dreamr_app"
discord: "https://dsc.gg/dreamr"
telegram: "https://t.me/dreamrsunite"
github: "https://github.com/dreamrsuntie"
youtube: "https://youtube.com/dreamrsunite"
twitch: ""
facebook: ""
instagram: "https://instagram.com/dreamr.app"
reddit: "https://reddit.com/r/Dreamr"
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Dreamr 是一款与 web3 集成的混合移动应用程序，供人们追求梦想。 Dreamr 利用社区建设功能、DeFi 和 p2p 市场为平台用户提供实现任何梦想的资源和工具！ Dreamr 通过 $DMR 代币为用户提供平台治理方面的决定性发言权，其中 33% 的供应通过奖励分配给社区。
Dreamr 生态系统包括一个由组织组成的集团，这些组织和谐地工作，围绕以下核心前提构建创新技术产品并制作高质量的励志内容；

  目标成就心理学，
  团结胜过分离，以及
  用科技将梦想付诸实践

Dreamr 的生态系统包括数字资产、技术产品和物理组件，例如 The Dream Machine Tour，它利用平台的社区来制作现实世界的活动和媒体。
Dreamr 的核心理念是首先交付其社区价值，并利用回馈作为一种实用模式，通过其慈善机构 Dream Machine Foundation 创造生态系统价值。迄今为止，Dream Universe 社区已为梦想贡献了超过 2,500,000 美元。
访问 dreamuniverse.org 了解更多信息

![dreamr-dapp-social-ethereum-image1_8e0a959ff56e587589d518c785725de8](dreamr-dapp-social-ethereum-image1_8e0a959ff56e587589d518c785725de8.png)