﻿---
title: "Drakeball Super"
description: "DrakeBall New World 是在#BSC 上开发的#PlaytoEarn #NFT RPG，通过#zerofee 加入前往新行星的旅程并赚取其他代币 xBALL"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "drakeball-super.png"
tags: ["NFT Games","Drakeball Super"]
categories: ["nfts"]
nfts: ["NFT Games"]
blockchain: "BSC"
website: "https://www.cryptodball.io/"
twitter: "https://twitter.com/DrakeballSuper"
discord: "https://discord.gg/ebKaCtcEpw"
telegram: "https://t.me/CryptoDrakeBall"
github: ""
youtube: "https://www.youtube.com/channel/UC_XNPQWHWV4pT_B1oCmQxrQ"
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: "https://drakeball-super.medium.com/"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
🎮Zeno World是一个新的元界，旨在成为区块链上最伟大的元界卡牌游戏。我们提供了一个战略游戏，通过与 Chainlink Oracle 提要以 $DBS 价格集成，以最稳定的方式赚取 $DBS。天使们将在不同的宇宙飞船上聚集在 CREWS 中去征服新的宇宙
📌Zeno World是币安智能链上基于合约的NFT游戏，搭配MetaMask/Trust Wallet/Safepal等Web3钱包，用于接受交易和支付gas费。
1️⃣ 我们目前所有的 NFT 类型（D.Char、S.Char、N.Char、Mystic Eggs、Partner NFT、Claws & Armors）都可以转换为 Zeno World 中使用的 NFT 来玩并赚取 $DBS。
2️⃣ Zeno Token (ZBALL) 可以通过将 SBALL/NBALL 以 10:1 的比例转换为 ZBALL 来为宇宙飞船提供燃料。
3️⃣ Amors 和 Gloves (Items - DBI) 将兑换为 Spaceship。
4️⃣ 魔人少女、楚楚、普尔玛……从神秘蛋开启。将成为名为 Angel NFT 的宇宙飞船上的勇士
6️⃣ Spaceship & Angel 必须在 CREW 中成立并签署 CREW CONTRACT 才能继续征服和赚钱。
7️⃣ 会有Chainlink提供的DBS Oracle feed，可用于平衡以$DBS支付的玩家与等值美元价值的投资和奖励。

![drakeballsuper-dapp-games-bsc-image1-500x315_4cecc3d08070641e8b1f61b0d0f279d2](drakeballsuper-dapp-games-bsc-image1-500x315_4cecc3d08070641e8b1f61b0d0f279d2.png)