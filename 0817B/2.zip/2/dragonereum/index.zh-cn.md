---
title: "Dragonereum"
description: "Dragonereum 是一款加密收藏游戏，我们"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "dragonereum.png"
tags: ["NFT Games","Dragonereum"]
categories: ["nfts"]
nfts: ["NFT Games"]
blockchain: "ETH"
website: "https://dragonereum.io/"
twitter: "https://www.twitter.com/dragonereum/"
discord: "https://discordapp.com/invite/WcGYHPX"
telegram: "https://t.me/dragonereum"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/dragonereum/"
reddit: ""
medium: "https://medium.com/@dragonereum"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Dragonereum 是一款加密收藏游戏，用户可以在其中拥有一条龙、交易他们的龙、杂交它们并与其他龙作战，并在此过程中收集奖励和成就。所有这些都是在区块链上以开放、可信和去中心化的方式完成的。区块链和龙的数字稀缺游戏。从2018年开始生活

Dragonereum 建立在以太坊区块链之上，是一款具有 PvP 战斗、高级育种、游戏内交易、奖励和成就的加密收藏游戏。你可以完全控制你的龙的命运。你会统治天空吗？

![dragonereum-dapp-games-eth-image1-500x315_e1dd20d0907012fb4b5218937a2f2e63](dragonereum-dapp-games-eth-image1-500x315_e1dd20d0907012fb4b5218937a2f2e63.png)