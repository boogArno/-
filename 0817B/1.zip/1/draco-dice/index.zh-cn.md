---
title: "Draco Dice"
description: "为乐趣而构建的跨游戏、跨链游戏 NFT！ Draco Dice 是插图精美的 RPG 骰子，用于跨多个 p2e 经济体的多个游戏。"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "draco-dice.png"
tags: ["High risk","Draco Dice"]
categories: ["nfts"]
nfts: ["High risk"]
blockchain: "BSC"
website: "https://dracodice.com/"
twitter: "https://twitter.com/playdracodice"
discord: "https://discord.gg/dracodice"
telegram: ""
github: ""
youtube: "https://youtube.com/dracodice"
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Draco Dice: Dicesweeper 是 Draco Dice NFT 的第一个 play-2-earn 集成。它完全可以在 Discord 中玩，无需 NFT 即可玩和赚取，并提供前所未有的独特游戏玩法。Draco Dice 是新一代代币化视频游戏的优质跨区块链游戏。拥有您的游戏资产，并与您的敌人作战！在网络上的游戏中收集和部署数千个独特的 NFT。加入我们的 Discord 服务器，获取频繁更新和独家赠品！游戏开发要求高、复杂且困难，区块链更是如此。这就是为什么 Draco Dice 是从头开始构建的，目的是通过为开发人员免费提供数千个现成的 NFT 模板来启动新的区块链游戏开发。

想象一下，如果您在电子游戏中拥有一个枪支皮肤，但您也能够将该皮肤带入其他游戏并在那里使用它。这就是 Draco Dice 的愿景——一个去中心化的武器库，你可以建立它并毫不费力地将其带入多个游戏！

![dracodice-dapp-games-bsc-image1-500x315_127752d7805dbfd1db7db99b9cffe4af](dracodice-dapp-games-bsc-image1-500x315_127752d7805dbfd1db7db99b9cffe4af.png)

