﻿---
title: "DokiDoki Finance"
description: "在复古日本体验 DeFi"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "dokidoki-finance.png"
tags: ["DeFi","DokiDoki Finance"]
categories: ["nfts"]
nfts: ["DeFi"]
blockchain: "ETH"
website: "https://dokidoki.finance/"
twitter: "https://twitter.com/dokidokifinance"
discord: "https://discord.com/invite/K32BeEY"
telegram: "https://t.me/ddnfg"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: "https://medium.com/@dokidoki.finance"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
我们的合约代码不是 sushi/yfi/curve 的一个分支。所有合约都是从头开始开发的。
我们的网站和产品视觉设计也是独一无二的——仅为 Doki Doki Finance 创建，而不是从其他来源抄袭。
我们名字中的“Doki Doki”是什么意思？
Doki doki” = 表示心跳迅速的日语表达，通常带有期待或兴奋。我们的目标是开发令人兴奋和时尚的产品，为我们的用户带来“Doki Doki”的感觉。

![dokidokifinance-dapp-defi-ethereum-image1_d75d13fdcc54f969d6e71934c2ed8ade](dokidokifinance-dapp-defi-ethereum-image1_d75d13fdcc54f969d6e71934c2ed8ade.png)