---
title: "Doodle Duckling Stamp"
description: "Doodle Duckling 邮票套装是一张优质邮票相册，里面装满了不同主题的著名收藏邮票。"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "doodle-duckling-stamp.png"
tags: ["Collectibles","Doodle Duckling Stamp"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: "BSC"
website: "https://doodleduckling.com/"
twitter: "https://twitter.com/DoodleDuckling"
discord: "https://discord.com/invite/vQKDFs8wWg"
telegram: "http://t.me/doodleduckling"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: "https://medium.com/@DoodleDuckling"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Doodle Duckling 邮票套装是一张优质邮票专辑，内含不同主题的著名收藏邮票。由 Doodle Duckling 的世界级艺术家精心制作，灵感来自人类历史上难忘的时刻，这些邮票是永恒和怀旧的精髓。Doodle Duckling 是一个社区驱动的集合，包含 8,888 个 NFT，生活在以太坊区块链上。每只小鸭都是独一无二的，有自己的个性、天赋和庸医！您想拥有一只小鸭并加入仅限 VIP 的泳池派对吗？不要再等一分钟了，现在就加入我们吧！

![doodleducklingstamp-dapp-collectibles-bsc-image1-500x315_f531528e9ccb41aee11b968dbe35c700](doodleducklingstamp-dapp-collectibles-bsc-image1-500x315_f531528e9ccb41aee11b968dbe35c700.png)