---
title: "Little Rocketman"
description: "Little Rocketman 是 9,999 个独特 NFT 的集合，这些 NFT 从生活在以太坊和 Immutable X 区块链上的手绘图中随机生成，作为 ERC-721 代币"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "little-rocketman.png"
tags: ["Collectibles","Little Rocketman"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: "Immutable X"
website: "https://dappradar.com/"
twitter: "https://twitter.com/nftrocketman"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---

HTML





Little Rocketman 是 9,999 个独特的 NFT 的集合，这些 NFT 从生活在 Ethereum 和 Immutable X 区块链上的手绘图中随机生成，作为 ERC-721 代币，每个都为赢得世界的尊重和权威而奋斗。

为什么要创建这个项目？ 在 12 个月内，我们保证 12 次空投其他 NFT。 一些空投将成为朋友，一些将成为艺术作品，在 Metaverse 中的 Rocketman 豪宅墙上会令人惊叹。

至高无上的领袖，我们心爱的小火箭人，想出了一个实现统治世界的绝妙计划……我们的科学家想出了一个天才的方法，将他克隆成一支光荣的秘密军队。



![1080x360](1080x360.jpg)