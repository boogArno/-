---
title: "Liquity"
description: "流动性是一种去中心化的借贷协议。"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "liquity.png"
tags: ["DeFi","Liquity"]
categories: ["nfts"]
nfts: ["DeFi"]
blockchain: "ETH"
website: "https://dappradar.com/"
twitter: "https://twitter.com/LiquityProtocol"
discord: "https://discord.com/channels/700620821198143498/827980594314608700"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Liquity 是一种去中心化的借贷协议，允许您以用作抵押的以太币提取无息贷款。 贷款以 LUSD（一种与美元挂钩的稳定币）支付，并且需要保持 110% 的最低抵押率。 除了抵押品外，贷款还由包含 LUSD 的稳定池和作为最后担保人的借款人共同担保。 在我们的文档中了解有关这些机制的更多信息。

![1080x360](1080x360.jpg)