---
title: "DopeWolves"
description: "一个 NFT 集合，由 Oasis 网络中的 4444 只具有涂料风格的狼组成。我们提供真正的实用性和独特的艺术风格"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "dopewolves.png"
tags: ["Collectibles","DopeWolves"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: "Oasis Network"
website: "https://dopewolves.com/"
twitter: "https://twitter.com/DopeWolvesNFT"
discord: "https://discord.gg/dopes"
telegram: "https://t.me/DopeWolves"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: "https://dopewolves.medium.com/"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Dope Wolves 是 Oasis Network 上的第一个 Wolves NFT 系列，具有原创、独家和手绘设计。我们的艺术家创造了 161 种资产，并将它们与 10 个特征配对。在该系列中，所有资产都按稀有度进行排名。我们的艺术家和 Dope Wolves 团队彻底检查了质量。Dope Wolves是8888个独特的化身（前444个狼，将属于GEN1，其他的4444个，属于GEN2)资产按稀有度排名，每一个资产都是手绘的，我们的艺术家会仔细检查质量。

![dopewolves-dapp-collectibles-oasis-image1-500x315_e777c292350dc7ecb7874ffd234086f4](dopewolves-dapp-collectibles-oasis-image1-500x315_e777c292350dc7ecb7874ffd234086f4.png)