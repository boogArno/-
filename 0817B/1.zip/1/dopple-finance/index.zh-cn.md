---
title: "Dopple Finance"
description: "Dopple 是 BSC 上的稳定币 DeFi 平台"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "dopple-finance.png"
tags: ["Exchanges","Dopple Finance"]
categories: ["nfts"]
nfts: ["Exchanges"]
blockchain: "BSC"
website: "https://dopple.finance/"
twitter: "https://twitter.com/dopplefi"
discord: ""
telegram: "https://t.me/dopplefi"
github: "https://github.com/DoppleFinance/dopple-contract"
youtube: "https://www.youtube.com/channel/UCrjhvTWYYOJuEVVuuH_0aBA"
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: "https://dopple-ecosystem.medium.com/"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Dopple 是稳定币 DEX，专为在币安智能链上高效交换稳定币而设计。 Dopple 的原生代币 DOPX 用于铸造 Dopple 的分数算法稳定币 KUSD。可用的稳定币池：KUSD、BUSD、USDT、DAI、USDC、USDN、TUSD、DOLLY 和 UST。

协议 稳定币互换算法 专为在币安智能链上高效交易稳定币和锚定资产而设计。以最优惠的价格交换您的稳定币。质押您的稳定币以获得高收益。

![dopplefinance-dapp-exchanges-bsc-image1-500x315_57392c1e817ed7875824c2fd2b68fefa](dopplefinance-dapp-exchanges-bsc-image1-500x315_57392c1e817ed7875824c2fd2b68fefa.png)

