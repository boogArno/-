﻿---
title: "Dolce&Gabbana: DGFamily Glass Box"
description: "随着 DGFamily NFT 社区的推出，Dolce&Gabbana 正在向他们的世界开放"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "dolce-gabbana-dgfamily-glass-box.png"
tags: ["Collectibles","Dolce&Gabbana: DGFamily Glass Box"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: "ETH"
website: "https://drops.unxd.com/"
twitter: "https://twitter.com/dolcegabbana"
discord: "https://discord.com/invite/unxd"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
DGFamily 玻璃盒可在未来几周在 UNXD 上访问的链上展示中兑换成分层 DGFamily 盒。
DGFamily Boxes 是打开 Dolce&Gabbana NFT 世界的钥匙——一个由典型的意大利奢侈品牌直接与 UNXD 合作的数字、物理和体验利益的世界。随着 DGFamily NFT 社区的推出，Dolce&Gabbana 正在向他们的世界开放。收藏家将能够加入这个标志性的意大利品牌，带领会员踏上在元宇宙及其他地方体验时尚的旅程。DGFamily 会员可以使用一系列独家产品，包括数字和实体可穿戴设备，包括独家 Dolce&Gabbana 赃物包。这些定制的作品将无法在其他任何地方获得。

![dolcegabbanadgfamilyglassbox-dapp-collectibles-ethereum-image1_4b88dbbf5faa96aacca08b786be377e8](dolcegabbanadgfamilyglassbox-dapp-collectibles-ethereum-image1_4b88dbbf5faa96aacca08b786be377e8.png)