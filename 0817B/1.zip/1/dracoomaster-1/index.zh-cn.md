---
title: "DracooMaster"
description: "一款策略类 Roguelike 套牌建造游戏。"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "dracoomaster-1.png"
tags: ["NFT Games","DracooMaster"]
categories: ["nfts"]
nfts: ["NFT Games"]
blockchain: "BSC"
website: "https://www.dracoomaster.com"
twitter: "https://twitter.com/Dracoo_Master"
discord: "https://discord.com/invite/dracoomaster"
telegram: "https://t.me/DracooMasterOfficial"
github: ""
youtube: "https://www.youtube.com/channel/UC682aHoh8rJPjgzERX80xiw"
twitch: ""
facebook: "https://business.facebook.com/DracooMaster-109958111471068"
instagram: "https://www.instagram.com/accounts/login/?next=/dracoomaster"
reddit: ""
medium: "https://medium.com/@Dracoo_Master"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
一款策略类 Roguelike 套牌建造游戏。 Dracoo 的卡牌安排在您的圣峰冒险中实现了实时多人在线竞技游戏的无限可能性。Dracoo Master 是一款全新的游戏，玩家通过游戏中的冒险和战斗来收集 DRA 代币。同时，玩家可以收集和进化不同种类的天龙座，通过战斗获得DRA代币。 Drac![section5_1.1bd1764f](section5_1.1bd1764f.png)oo NFT )可以在 NFT 市场上交易。在游戏中赢取 DRA 代币，并用它们来决定游戏的未来！