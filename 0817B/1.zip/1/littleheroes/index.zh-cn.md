---
title: "LittleHeroes"
description: "区块链驱动的游戏，注入了独特的实验代币经济学。 锻造、战斗和赌注通往胜利的道路！"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "littleheroes.png"
tags: ["NFT Games","LittleHeroes"]
categories: ["nfts"]
nfts: ["NFT Games"]
blockchain: "Polygon"
website: "https://dappradar.com/"
twitter: "https://twitter.com/littleheroes_io"
discord: "https://discord.com/invite/AEeewbzz79"
telegram: ""
github: ""
youtube: "https://www.youtube.com/channel/UCwyOJNZS8hxLdn5Oz1tfq6A"
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
HTML






LittleHeroes 是一款赚取区块链驱动的游戏。
您可以创建强大的英雄、战斗、赌注或简单地收集它们。 玩这款游戏，您可以获得原生的 $FORGE 代币。
我们还有一些其他很酷的功能，例如：

   社区控制的铸币流动性
   多种质押机制
   NFT资产赋能
   价值注入英雄

饥饿游戏上线了！

战略游戏，战斗或投降，由您选择！

✅创建自己的战斗或加入现有的战斗！
✅设定玩家人数
✅自己设定费用
✅声称英雄
✅赢$FORGE！

![1080x360](1080x360.jpg)