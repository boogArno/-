---
title: "Dot Arcade"
description: "Dot Arcade 是 Arcade 和 Moba 游戏 gerne 之间的第一个游戏组合。"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "dot-arcade.png"
tags: ["NFT Games","Dot Arcade"]
categories: ["nfts"]
nfts: ["NFT Games"]
blockchain: "BSC"
website: "https://dapp.dotarcade.io/home"
twitter: "https://twitter.com/dotarcadegame"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: "https://www.facebook.com/dotarcadegaming"
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
您加入世界各地的众多玩家，并有机会单独或与您的氏族一起玩以赚取 NFT。 Dot Arcade 中的每场战斗看起来都像帝国时代（AOE）中的简单战斗，它像 AOE 一样有四个时代：青铜时代、白银时代、黄金时代和钻石时代。您可以加入一个氏族，您可以是氏族首领或成员。每天或每周都有很多活动，您可以通过参加活动获得很多礼物并完成您的任务。在 Dot Arcade 中，您可以参加许多锦标赛并获胜以获得 NFT 物品或代币。

![dotarcade-dapp-games-bsc-image1-500x315_98a57d2ffa184344bd736945e87b4c4c](dotarcade-dapp-games-bsc-image1-500x315_98a57d2ffa184344bd736945e87b4c4c.png)