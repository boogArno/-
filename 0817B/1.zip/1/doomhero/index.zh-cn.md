---
title: "DoomHero"
description: "全球首款 NFT+ DeFi+ RPG 3D 策略游戏。基于具有最高质量 GameFi 的 BSC：Play to Earn！"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "doomhero.png"
tags: ["NFT Games","DoomHero"]
categories: ["nfts"]
nfts: ["NFT Games"]
blockchain: "BSC"
website: "https://doomhero.io/"
twitter: "https://twitter.com/DoomHero3"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
什么是末日英雄？
全球首款 NFT+ DeFi+ RPG 3D 策略游戏。基于具有最高质量 GameFi 的 BSC：Play to Earn！
如何开始和下载 Doom Hero？
从官方网站购买宝箱并获得英雄后，您可以在此处下载应用程序。
扫描二维码登录游戏，畅玩赚钱。
如何获得英雄？
宝箱一共有三种，打开的宝箱越好，获得的英雄就越好。英雄会影响游戏中竞技场的每日DHG上限和胜率

![tap-1](tap-1.png)