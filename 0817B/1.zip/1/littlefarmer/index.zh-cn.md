---
title: "LittleFarmer"
description: "多边形网络上的小产量农民"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "littlefarmer.png"
tags: ["DeFi","LittleFarmer"]
categories: ["nfts"]
nfts: ["DeFi"]
blockchain: "Polygon"
website: "https://dappradar.com/"
twitter: "https://twitter.com/littlefarmer_"
discord: ""
telegram: "https://t.me/littlefarmer_poly"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: "https://medium.com/@littlefarmerfarm"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
LittleFarmer 是一个在 Polygon/Matic 网络和 Quickswap 交易所上运行的去中心化农场，具有许多其他功能，可让您赚取和赢取代币。 我们正在尝试做的是创建一个永久通缩令牌，它允许具有足够燃烧机制的恒定价格泵。 我们不是试图取代掉期和交换，而是为系统增加价值，并为人们创造一个合适和可持续的环境来生产高年利率的农场。





![littlefarmer-dapp-defi-matic-image1_6dd10b352f166bca5e787c0c2f2e003c](littlefarmer-dapp-defi-matic-image1_6dd10b352f166bca5e787c0c2f2e003c.png)