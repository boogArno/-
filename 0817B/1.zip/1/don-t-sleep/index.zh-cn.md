---
title: "Don't Sleep"
description: "将 BNB 从困倦的手中拿走。在计时器运行到 0 之前抽出游戏 HODL 存储，当您进行计时器重置以及没有其他人在您之后抽水时......好吧，你赢了！"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "don-t-sleep.png"
tags: ["Gambling","Don't Sleep"]
categories: ["nfts"]
nfts: ["Gambling"]
blockchain: "BSC"
website: "https://dontsleep.xyz/"
twitter: ""
discord: ""
telegram: "https://t.me/dontsleep_xyz"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
将 BNB 从困倦的手中拿走。在计时器运行到 0 之前抽出游戏 HODL 存储，当您进行计时器重置以及没有其他人在您之后抽水时......好吧，你赢了！一个可选的计时器让用户可以选择何时退出“不睡眠”，程序可以简单地停止运行或停止运行并关闭或休眠计算机。用户还可以选择程序开始运行的时间，从未来 5 分钟到 48 小时不等

![dontsleep-dapp-gambling-bsc-image1-500x315_0d670102e1c02b0655024cac8ab47003](dontsleep-dapp-gambling-bsc-image1-500x315_0d670102e1c02b0655024cac8ab47003.png)