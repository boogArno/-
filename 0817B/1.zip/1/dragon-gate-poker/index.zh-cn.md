﻿---
title: "Dragon Gate Poker 射龙门"
description: "龙门扑克是一个著名和受欢迎的扑克游戏"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "dragon-gate-poker.png"
tags: ["Gambling","Dragon Gate Poker 射龙门"]
categories: ["nfts"]
nfts: ["Gambling"]
blockchain: "EOS"
website: "https://dgatepoker.com/"
twitter: ""
discord: ""
telegram: "http://t.me/eos_dragon"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Dragon Gate Poker 是一款著名且受欢迎的扑克游戏。这个游戏不仅简单而且令人兴奋，它属于PVP（玩家对玩家）游戏。在每场比赛开始时，球员被随机排列座位顺序。玩家必须下注才能开始。随机抽取两张牌组成“门”。如果玩家在“门”内抽到一张牌，玩家将赢得 1.95 倍的赌注。如果抽出的牌在“门”之外，则赌注输掉并进入底池。在所有玩家都有机会抽牌后，重新洗牌。当罐子空了时游戏结束。

![dragongatepoker-dapp-gambling-eos-image1-500x315_86b21ee5090fcb22b0a9a0c64e91c096](dragongatepoker-dapp-gambling-eos-image1-500x315_86b21ee5090fcb22b0a9a0c64e91c096.png)