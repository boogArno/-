---
title: "dotdotdots"
description: "点点是生活在固体中的奇怪的邪教生物。"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "dotdotdots.png"
tags: ["Collectibles","dotdotdots"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: "ETH"
website: "https://opensea.io/"
twitter: "https://twitter.com/opensea"
discord: "https://discord.gg/opensea"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/opensea/"
reddit: "https://reddit.com/r/opensea"
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
点点是生活在固体中的奇怪的邪教生物。它们在代码中伪装成小数，很少被人眼自然地看到。它们通常被称为臭虫，但它们的种类是未知的。
Dotdotsdots 可以使用 mint 功能直接从合约中铸造，价格为 0.05 ETH，每笔交易最多 5 个。最初将有 4360 dotdotdots 用于薄荷，但随着以太坊历史最高价格的上涨会增加，上限为 10,000

![dotdotdots-dapp-collectibles-ethereum-image1-500x315_0955c75c68297a17fb58ebda89d59c44](dotdotdots-dapp-collectibles-ethereum-image1-500x315_0955c75c68297a17fb58ebda89d59c44.png)