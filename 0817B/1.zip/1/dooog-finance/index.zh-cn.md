﻿---
title: "Dooog Finance"
description: "1.流动性锁定
2.自动流动性
3.自动烧录
4.收获锁仓
5.反鲸
6.存款费用再分配
7.推荐计划
8.没有迁移代码"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "dooog-finance.png"
tags: ["DeFi","Dooog Finance"]
categories: ["nfts"]
nfts: ["DeFi"]
blockchain: "BSC"
website: "https://dooog.fi"
twitter: "https://twitter.com/Dooog_Fi"
discord: ""
telegram: "https://t.me/DooogFi"
github: "https://github.com/dooogfi/dooog-farm"
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: "https://dooogfi.medium.com/"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
1.流动性锁定
流动性锁定是反鲸策略的一部分，以稳定代币价格。我们设置了 DOOOG-BUSD 矿池、DOOOG-BNB 矿池、DOOOG 单矿池的流动性锁定，自耕作开始 48 小时。
2.自动流动性
PANTHER 的每次转让必须缴纳 5% 的转让税。 4% 的转让税通过合约自动添加到流动性池中，以不断提高价格下限。
3.自动烧录
正如我们上面提到的，PANTHER 的每次转让都必须缴纳 5% 的转让税。 4% 的转让税将分配给自动流动性获取。剩下的1%的转让税将立即被烧掉。整个过程是自动的。
4.收获锁仓
收获锁定是一种独特的奖励锁定机制，用于限制收获的频率。它旨在防止农业套利机器人不断收获和倾销。
5.反鲸
超过总供应量 1% 的转账将被拒绝。随着总供应量的增加，这个比例会降低。
6.存款费用再分配
当用户在 Dooog Finance 上进行质押时，将收取 4% 的押金。
7.推荐计划
已实施链上推荐计划，以激励用户邀请朋友加入农场。邀请者可以永久赚取他/她朋友收入的 1%。
8.没有迁移代码
MasterChef 合约中的迁移代码已被删除。

![1_kqphZSu8yBN9isl2tO1TBw](1_kqphZSu8yBN9isl2tO1TBw.jpeg)