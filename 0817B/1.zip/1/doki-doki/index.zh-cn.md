﻿---
title: "Doki Doki"
description: "世界上第一个用于数字艺术、收藏品等的游戏化 NFT 平台。"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "doki-doki.png"
tags: ["Marketplaces","Doki Doki"]
categories: ["nfts"]
nfts: ["Marketplaces"]
blockchain: "Polygon"
website: "https://dappradar.com/"
twitter: "https://twitter.com/dokidokifinance"
discord: "https://discord.com/invite/K32BeEY"
telegram: ""
github: ""
youtube: "https://www.youtube.com/channel/UCHKQaCYkq3zuHOi77aJ3cUA"
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/dokidoki.degacha/"
reddit: ""
medium: "https://medium.com/@dokidoki.finance"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
DeGacha 是一个独一无二的 NFT 平台，它将令人上瘾的 Gachapon 机器与数字艺术、收藏品和 DeFi 质押相结合，创造难忘的体验！
Gachapon (ガチャポン) 是日本的一种文化现象，各个年龄段的人都可以玩耍和享受。 Gachapon 机器分配包含随机收藏品的胶囊，发现你会得到什么是一个谜。
想成为扭蛋机的拥有者吗？我们为艺术家、品牌和其他项目提供 Gacha 服务。今天申请！

![dokidoki-dapp-marketplaces-matic-image1_e0dad27eba15ec4ac123dcd4bfc36a06](dokidoki-dapp-marketplaces-matic-image1_e0dad27eba15ec4ac123dcd4bfc36a06.png)