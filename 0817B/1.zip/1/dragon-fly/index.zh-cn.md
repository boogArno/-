---
title: "Dragon Fly"
description: "Dragon Fly 是一款休闲游戏，您可以通过在龙世界中弹跳和飞行您的龙来赚取 GEM。"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "dragon-fly.png"
tags: ["NFT Games","Dragon Fly"]
categories: ["nfts"]
nfts: ["NFT Games"]
blockchain: "Telos"
website: "https://play.google.com"
twitter: "https://twitter.com/dragonfly"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Dragon Fly 是一款建立在 Telos 区块链上的休闲游戏，玩家可以通过在龙世界中弹跳和飞行他们的龙来赚取 GEM。作为一只刚孵化的幼龙，你的翅膀仍然太小而无法飞翔。然而，这不会阻止你开始你的第一次冒险。这些领域充满了弯曲的山丘。沿着它们滑动并精确计时，以建立动力并飞向天空。不过要快！龙妈担心你的下落，已经出发去结束你的旅程，把你带回巢穴。创业板可以在Newdex上交易TLOS，以有趣、随意的方式飞行和弹跳你的龙并赚取积分。

![dragonfly-dapp-games-telos-image1-500x315_24d399824f5b2b48a975b2df60c59b07](dragonfly-dapp-games-telos-image1-500x315_24d399824f5b2b48a975b2df60c59b07.png)