---
title: "Five Stars"
description: "'五星'，硬核RPG，您可以在其中体验最强的策略和成长玩法。
玩家可以制作 NFT 并自由转让。"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "five-stars.png"
tags: ["NFT Games","Five Stars"]
categories: ["nfts"]
nfts: ["NFT Games"]
blockchain: "Klaytn"
website: "https://www.fivestars.com/"
twitter: "https://twitter.com/FiveStars"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: "https://www.facebook.com/FiveStarsCard/"
instagram: "https://www.instagram.com/fivestars/"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
五星'，硬核RPG，你可以体验最强的策略和成长玩法。
如果您正在寻找高级移动角色扮演游戏，请加入我们。
◆ 硬核策略对战 120 多个不同角色的组合带来策略的乐趣！用有效的阵型布局压倒你的对手！
◆ 迷宫，无法无天的地牢 迷宫地牢，您可以每天参加 3 次激烈的竞争！实时PVP攻击你的对手，赢取稀有装备！
◆ 次元裂缝，惊险刺激到最后一刻！部队之间的实时战争。杀死世界首领以赢取奖励。
◆ 市场体系，自治经济的核心！不再孤独的RPG！随意通过市场交易物品！
◆ 强化系统，装备成长的关键！增强系统，RPG成长的核心功能！创建您自己的强大而精美的设备！
◆ 分享的喜悦！装备物品可以做成NFT，用户可以自由转让。

![fivestars-dapp-games-klaytn-image1_09fa727c09df19faff96710eb553c91a](fivestars-dapp-games-klaytn-image1_09fa727c09df19faff96710eb553c91a.png)
