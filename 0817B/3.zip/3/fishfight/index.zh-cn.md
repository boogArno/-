---
title: "FishFight"
description: "打鱼
一款可收藏的 NFT 游戏，您可以在其中去外星世界钓鱼

薄荷/捕捞 NFT

战斗☠️ FISH (PVP)
（赚取 $FISHFOOD/烧掉 $FISH）

BREED💞你的$FISH"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "fishfight.png"
tags: ["NFT Games","FishFight"]
categories: ["nfts"]
nfts: ["NFT Games"]
blockchain: "Harmony"
website: "https://fishfight.one/"
twitter: "https://twitter.com/FishFight1NFT"
discord: "https://discord.com/invite/23ArJsQKnT"
telegram: "https://t.me/+FB0g4lKU8GBlZTkx"
github: "https://github.com/TrustlessTeam"
youtube: "https://www.youtube.com/channel/UCtsLKvcpIaSHj02YL3C12GA"
twitch: ""
facebook: "https://www.facebook.com/gaming/FishFight1NFT"
instagram: "https://www.instagram.com/fishfight1nft/"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
FishFight 是一款可收藏的 NFT 游戏，您可以在其中捕捉到外星世界的 FISH。
-- 一旦你抓住了你的 $FISH，他们就只想做 $ONE 的事情：战斗！

- 在那之后，他们会想要繁殖......
收集并享受与您和其他人在世界各地的 $FISH 的互动体验！
抓住他们，
交易它们，
卖掉这些，
通过游戏赚取 FISHFOOD、FISHEGG 和 FISHSCALES！
包括从#DefiKingdoms #Bloaters 等其他游戏中喂它们鱼
WalletConnect 支持即将推出！

![fishfight-dapp-games-harmony-image1_cb186b3a26e2281c884f5ff58f730d26](fishfight-dapp-games-harmony-image1_cb186b3a26e2281c884f5ff58f730d26.png)
