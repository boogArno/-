---
title: "Feudalz"
description: "封建制出现以保护他们的农民.当系统顺利运行时,它会给每个人带来和平与繁荣."
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "feudalz.png"
tags: ["Collectibles","Feudalz"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: "ETH"
website: "https://feudalz.io/"
twitter: "https://twitter.com/feudalznft"
discord: "https://discord.com/invite/zZJDyNSg5E"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
封建制出现以保护他们的农民。当系统顺利运行时，它会给每个人带来和平与繁荣。 4,444 个具有所有权证明的独特收藏角色存储在以太坊区块链上。 CryptoArt 的现代运动。元界即将登陆。

Feudalz NFT 游戏的实用代币，4,444 humanz 的集合，您可以使用它来赚取 $GOLDZ。有了这个 $GOLDZ，你可以雇佣 Elvez 来保卫你的人民，或者通过雇佣 Orcz 来发动袭击，掠夺其他 Feudalz 的 $GOLDZ。还可以使用 $GOLDZ 构建您的 Landz 并解锁 Metaverse 上的功能。

![feudalz-dapp-collectibles-ethereum-image1_af85186e745e3b2c0a94c1c548bf5dce](feudalz-dapp-collectibles-ethereum-image1_af85186e745e3b2c0a94c1c548bf5dce.png)
