---
title: "Fistiana"
description: "FISTIANA是一款体育娱乐Dapp，未来将搭载基于Web3.0的可穿戴设备，实现身临其境的游戏体验。"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "fistiana.png"
tags: ["NFT Games","Fistiana"]
categories: ["nfts"]
nfts: ["NFT Games"]
blockchain: "BSC"
website: "https://fistiana.org/"
twitter: "https://twitter.com/fistianaweb3"
discord: "https://discord.gg/qFSEyKyqD4"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: "https://medium.com/@fistianaweb3"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
FISTIANA是一款体育娱乐Dapp，未来将搭载基于Web3.0的可穿戴设备，实现身临其境的游戏体验。
FISIANA 内嵌 Game-Fi 和 Social-Fi，不受地域和时间限制，让玩家在享受体育娱乐的同时获得丰厚的代币奖励。玩家只需要选择自己的战士即可参与FISIANA的任何模式。活动结束后，用户将获得相应的代币奖励。这将鼓励玩家积极战斗并参与奖励驱动的活动，最终将 FISIANA 打造为一个整合社交和游戏元世界的平台。

![1500x500](1500x500.jpg)
