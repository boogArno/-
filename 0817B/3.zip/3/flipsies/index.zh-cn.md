﻿---
title: "Flipsies"
description: "Flipsies 是一种源自扑克中的“掷硬币”或“翻转”的游戏，您和您的对手都有相同的机会赢得这手牌。"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "flipsies.png"
tags: ["Gambling","Flipsies"]
categories: ["nfts"]
nfts: ["Gambling"]
blockchain: "TRON"
website: "https://dappradar.com/"
twitter: "https://twitter.com/Flipsiesflips"
discord: "https://discord.com/invite/RAsBhMcZ8n"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: "https://medium.com/@flipsiesflips"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Flipsies 是一款您在任何赌场都找不到的游戏，但它是一种众所周知的赌博游戏，通常在私人游戏结束时玩。 Flipsies 是整个地下纸牌游戏中的固定装置，通常以掷硬币、射击或其他名称命名。这是（我们知道的）flipsies 第一次出现在网上，我们想不出比 TRON 区块链更好的启动方式了。
大多数玩家认为他们可以在网上赌场被骗，在大多数情况下他们是对的。从技术上讲，在线赌场很容易欺骗您。在加密赌博世界中，我们有一个称为可证明公平的解决方案，这允许通过实施智能合约实现完全透明。智能合约包含一组不可篡改并自动执行的规则。任何一方都可以审计这些智能合约，因为它们是公开的。我们的随机数生成器在这些智能合约上执行，这意味着在技术上不可能以任何方式操纵它们。
在翻转中，你和你的对手都有平等的机会赢得这手牌。我们添加了一个可选的边注，您可以在翻牌圈下注大多数颜色的花色（红色或黑色中的 2 个或更多），这通常在私人扑克游戏中进行。 Flipsies 遵循标准的德州扑克手牌排名，这些排名在游戏右上角的下拉菜单中提供。
第 1 步：你得到两张牌，房子也得到两张牌。
第2步：选择您的翻转下注（扑克手）的大小和您的翻牌颜色下注，没有进一步的下注。
第 3 步：翻牌（前 3 张牌）、转牌（第 4 张牌）和河牌（第 5 张牌）都用完了——这些是公共牌。

![flipsies-dapp-gambling-tron-image2_b0dd7c75cffcd66d8ba420c3620468b2](flipsies-dapp-gambling-tron-image2_b0dd7c75cffcd66d8ba420c3620468b2.png)