---
title: "FireBusd"
description: "质押 $BUSD 以每天铸造 2% 的 $FireBusd。质押 $FireBusd 每天可赚取 4% 的 $FireBusd 并增加您在 $FireBusd 供应中的份额。"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "firebusd.png"
tags: ["High risk","FireBusd"]
categories: ["nfts"]
nfts: ["High risk"]
blockchain: "BSC"
website: "https://www.firebusd.finance/"
twitter: "https://twitter.com/@FireBusd/"
discord: ""
telegram: "https://t.me/firebusd0"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/firebusd.finance/"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
随着更多用户投资 BUSD，FireBusd 的价值将会上升。
1. 将 BUSD 输入机器，每天获得 FireBusd 代币的质押奖励（每天 2%）。您可以随时领取您的 FireBusd 奖励。您不能取消抵押您的 BUSD 代币。
2. 您的 FireBusd 代币有两种选择，您可以将它们出售以换取 BUSD，或者您可以质押它们以赚取更多 FireBusd 代币（每天 4%）。 FireBusd 质押锁定 7 天
3. 术语
3.1。 Total Supply : FireBusd 可以存在的最大数量
3.2.循环供应：当前在钱包中的 FireBusd 代币数量
3.3.可用供应：（总供应 - 循环供应）
3.4. FireBusd 价格：（总 BUSD 余额/流通供应）
4. Mint FireBusd - 当您从铸币中获得 FireBusd 时，它会从可用供应中移除并添加到循环供应中
5. 出售 FireBusd - 当您出售 FireBusd 时，它会从流通供应中移除并添加到可用供应中

![firebusd-dapp-high-risk-bsc-image1_dee23402f9080ba5462e3b0670b8a645](firebusd-dapp-high-risk-bsc-image1_dee23402f9080ba5462e3b0670b8a645.png)
