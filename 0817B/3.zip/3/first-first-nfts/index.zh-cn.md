---
title: "First First NFTs"
description: "第一个关于 NFT 的链上生成文本 NFT。"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "first-first-nfts.png"
tags: ["Collectibles","First First NFTs"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: "ETH"
website: "https://opensea.io/"
twitter: "https://www.twitter.com/_deafbeef"
discord: "https://discord.gg/ZEWCVTpuPV"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/https://discord.gg/"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
第一个关于 NFT 的链上生成文本 NFT。

FIRST 是讽刺性生成文本的集合。它既嘲笑又深情地纪念了大约 2021 年 9 月 NFT 加密文化的许多方面。所有初级销售和二级销售的版税都捐赠给 GiveDirectly.org 慈善机构。

FIRST 是讽刺性生成文本的集合。它既嘲笑又深情地纪念了 2021 年 9 月左右 NFT 加密文化的许多方面。

以太坊区块链的历史数据丰富，可以追溯到 2015 年。从那时起，NFT 和以太坊区块链发生了很多事情。从 ENS 到 Axie Infinity，它们都在以太坊区块链和宏观 NFT 空间的发展中发挥了作用。

感谢 Leonidas.eth，我能够收集在 Etherum 区块链上创建的一些最重要的 NFT 列表。但是，此列表不包括 Leonidas 时间轴上的每个 NFT。

![firstfirstnfts-dapp-collectibles-ethereum-image2_fa864ec978d7799f1176c9817ff4ad0e](firstfirstnfts-dapp-collectibles-ethereum-image2_fa864ec978d7799f1176c9817ff4ad0e.png)
