---
title: "Lotus Swap Polygon"
description: "Lotus Swap - 在 Polygon (MATIC) 网络上运行的 DeFi Yield Farm 应用程序"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "lotus-swap-polygon.png"
tags: ["DeFi","Lotus Swap Polygon"]
categories: ["nfts"]
nfts: ["DeFi"]
blockchain: "Polygon"
website: "https://polygon.lotusswapdefi.com/"
twitter: "https://twitter.com/LotusSwap"
discord: ""
telegram: "https://t.me/lotusswapdefi"
github: "https://github.com/lotusswap"
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
莲花交换多边形
打开 Dapp

莲花交换多边形
Lotus Swap - 在 Polygon (MATIC) 网络上运行的 DeFi Yield Farm 应用程序

莲花交换多边形统计
该数据代表被跟踪智能合约的原始链上活动

![lotusswappolygon-dapp-defi-matic-image1_2dfc1bf05f448d715026a561ee6e63c5](lotusswappolygon-dapp-defi-matic-image1_2dfc1bf05f448d715026a561ee6e63c5.png)