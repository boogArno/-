---
title: "Livepeer"
description: "Decentralized live video streaming protocol"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "livepeer.png"
tags: ["Social","Livepeer"]
categories: ["nfts"]
nfts: ["Social"]
blockchain: "ETH"
website: "https://dappradar.com/"
twitter: "https://twitter.com/"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
用于 DApp 的去中心化直播视频流协议

推特更新🚨

我们的 Twitter 句柄现在是 @Livepeer！ 🎉

🔁 通过转推传播信息！

Livepeer 本周看到价格下跌。
Livepeer 的价格在过去 7 天下跌了 0.63%。 在过去 24 小时内，价格下跌了 3.07%。 在过去一个小时内，价格下跌了 2.02%。 当前价格为每 LPT 11.57 欧元。 Livepeer 从 98.683757 欧元的历史高点下跌了 88.28%。

当前流通量为 24,425,746.875 LPT。

在社交媒体上直播同行。
截至 2022 年 8 月 15 日，在 Twitter 和 Reddit 上的 1,722,881 条社交媒体帖子中，有 54 条提到了 Livepeer。 79 个独特的人在谈论 Livepeer，该货币在收集的帖子中的大多数提及和活动中排名第 866 位。

![1080x360](\1080x360.png)