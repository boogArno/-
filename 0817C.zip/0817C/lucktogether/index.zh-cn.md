---
title: "LuckTogether"
description: "LuckTogether 是一个开源的去中心化协议，用于无损失有奖游戏和挖矿."
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "lucktogether.png"
tags: ["DeFi","LuckTogether"]
categories: ["nfts"]
nfts: ["DeFi"]
blockchain: "BSC"
website: "https://www.lucktogether.com/"
twitter: "https://twitter.com/LuckTogether"
discord: ""
telegram: "https://t.me/lucktogether_bsc"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
LuckTogether 是一个开源和去中心化协议，用于无损奖金游戏和挖矿，由 LUCK 代币持有者管理。
LuckTogether 希望打造一种能够让所有人受益的幸运抽奖模式。收集小资产组成奖池，一起赚取红利，然后抽奖。在这种模式下，每个人都永久有资格免费参与游戏并通过运气赚取财富。资产集齐后，我们希望能将其中的一部分用于帮助有需要的人，让幸运的种子播种到世界的每一个角落。让阳光温暖世界的每一个角落，我们永远期待美好的未来！

![lucktogether-dapp-defi-bsc-image2_4b1b926008e88a12a4f14c5d40ce31be](lucktogether-dapp-defi-bsc-image2_4b1b926008e88a12a4f14c5d40ce31be.png)