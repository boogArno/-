---
title: "Loopring Exchange"
description: "以太坊上可扩展的非托管交易所"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "loopring-exchange.png"
tags: ["Exchanges","Loopring Exchange"]
categories: ["nfts"]
nfts: ["Exchanges"]
blockchain: "ETH"
website: "https://loopring.org/"
twitter: "https://twitter.com/loopringorg"
discord: ""
telegram: ""
github: ""
youtube: "https://www.youtube.com/watch?v=FEf6GC5p8hU&t=1s"
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Loopring 是一种使用 zkRollup 在以太坊上构建高性能、非托管、订单簿交换的协议。

介绍 Loopring DAO 投票！💙

社区将选择他们想用路印协议费用激励哪些流动性提供者

通过在 L2 上与您的 LRC 投票来发表意见

![1500x500](1500x500.jpg)