---
title: "Lottery Token"
description: "LOT 是币安智能链上第一个与乐透相关的代币."
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "lottery-token.png"
tags: ["Gambling","Lottery Token"]
categories: ["nfts"]
nfts: ["Gambling"]
blockchain: "BSC"
website: "https://lotterytoken.net/"
twitter: "https://twitter.com/lottery_token"
discord: "https://discord.gg/WBKDXCVKbS"
telegram: "https://t.me/lotterytokenchat"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
彩票代币是币安智能链上第一个与乐透相关的代币。它在合约本身中具有自动化和集成的彩票。持有人无需购买门票，持有最少的金额即可获得终身参与。 Lotterypool 充满了每笔交易 6% 费用的 2%，另外 2% 立即重新分配给所有持有者，另外 2% 被烧毁。因此，彩票的频率是基于流量的。

![lotterytoken-dapp-gambling-bsc-image1_f1f85cd167adc2559e4757ebc35ff5e2](lotterytoken-dapp-gambling-bsc-image1_f1f85cd167adc2559e4757ebc35ff5e2.png)