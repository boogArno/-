---
title: "LootBlocks"
description: "自定义无代码 HRC20 + HRC721 战利品箱创建/分发平台"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "lootblocks.png"
tags: ["Other","LootBlocks"]
categories: ["nfts"]
nfts: ["Other"]
blockchain: "Harmony"
website: "https://lootblocks.one/"
twitter: "https://twitter.com/LootBlocks_"
discord: "https://discord.com/invite/5ngbUpMcqk"
telegram: "https://t.me/joinchat/-SbWuK5wxiM0OGUx"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
在区块链上创建一个战利品箱并与您的社区分享。打开去中心化的战利品箱，赢取高价值资产。战利品块可以容纳 HRC20s + HRC721s。
🧙 区块链战利品盒 $LBLOX

从/发现稀有宝藏中赚钱。

（创建自己的）

战利品块可以容纳#NFTs 和/或#Crypto。 （ERC721 + ERC20）

![lootblocks-dapp-other-harmony-image1_817127a95719a5fbe183167f1dfddf89](lootblocks-dapp-other-harmony-image1_817127a95719a5fbe183167f1dfddf89.png)