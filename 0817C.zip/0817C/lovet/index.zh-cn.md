---
title: "LOVET"
description: "F it，我不在乎，我喜欢它：Polygon 上 1024 个 NFT 生成艺术的集合。 Python 代码、SVG 文件."
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "lovet.png"
tags: ["Collectibles","LOVET"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: "Polygon"
website: "https://0xlovet.com/"
twitter: "https://twitter.com/0xLovet"
discord: ""
telegram: ""
github: "https://github.com/0xLovet"
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/0xlovet/"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Polygon 上 1024 个生成艺术的 NFT 集合。该项目于 2021 年 12 月开始，旨在为加密空间带来独特的 NFT 生态系统。
用 Python 编写的自定义代码已用于生成整个集合。这个想法是为了实现一个简单但令人印象深刻的结果，因此使用了最基本的几何形状：圆形、线条和三角形。图像是 SVG 文件，这意味着它们可以无限放大。
![lovet-dapp-collectibles-matic-image1_8f4b50f7ebf3e0fa10075fa6f9cd6531](lovet-dapp-collectibles-matic-image1_8f4b50f7ebf3e0fa10075fa6f9cd6531.png)