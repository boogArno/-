﻿---
title: "LOT.TRADE"
description: "LOT.TRADE 是通用的 NFT/DEX/CEX 游戏锦标赛平台."
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "lot-trade.png"
tags: ["DeFi","LOT.TRADE"]
categories: ["nfts"]
nfts: ["DeFi"]
blockchain: "BSC"
website: "https://lot.trade/"
twitter: "https://twitter.com/WLOCT"
discord: ""
telegram: "https://t.me/wloctchat"
github: ""
youtube: ""
twitch: ""
facebook: "https://www.facebook.com/lot.traders"
instagram: ""
reddit: ""
medium: "https://purefi-protocol.medium.com/"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
LOT.TRADE (LOT) 平台通过定期的锦标赛、战斗和挑战来代表加密交易的游戏化和普及化，目标是成为世界上最好的交易者。自定义锦标赛并赢得大奖。赌徒的赌注。 NFTs 作为获奖者的奖励和授权访问：

  加密货币交易者/游戏玩家的专业 LOT.TRADE；
  世界最佳交易者/游戏玩家的官方排名。

这个怎么运作：
第 1 步 – 自由交易者在 LOT.TRADE 中注册并链接到他的交易所/LP/NFT 平台交易账户；
第 2 步 – 缴纳比赛费用并参加比赛；
第三步——智能合约玩家排名和奖金分配。
去中心化和分布式 LOT 架构基于两个分布式寄存器的核心：
区块链#1：
BSC（Binance Smart Chain）被用作最佳选择。
区块链#2：
IPFS（星际文件系统）是与 BSC 集成的分布式文件系统，用于存储和访问大量与 NFT 相关的游戏和图形信息。
去中心化和分布式 LOT 架构提供
·   通过 BSC 非托管钱包和锦标赛智能合约控制所有时间玩家的资产；
· 具有程序化和透明的游戏逻辑、奖池分配和评分点的锦标赛智能合约；
·   统一透明和自动化的评级逻辑；
·   代币化、佣金分配和LOTT流动性供应的去中心化机制；
·      用于协议管理和项目开发的 DAO 机制。

![1500x500](1500x500.jpg)