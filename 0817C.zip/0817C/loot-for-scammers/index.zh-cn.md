---
title: "Loot (for Scammers)"
description: "sLoot 就是战利品（针对诈骗者）."
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "loot-for-scammers.png"
tags: ["Collectibles","Loot (for Scammers)"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: "ETH"
website: "https://www.sloot-project.com/"
twitter: "https://twitter.com/sLootnft"
discord: "https://discord.com/invite/vz3PUFpshB"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
sLoot 是随机生成并存储在商务休闲装上的骗子装备。如果你骗人，你还不如有一些战利品。故意省略统计信息、图像和其他功能以供其他人解释。随意以任何你想要的方式使用 Loot。
无论您是想向人们展示您的假兰博基尼，还是告诉他们您是尼日利亚王子，您都将拥有完成卑鄙行为所需的工具。

![E-5Kzg2XMAQf_C1](E-5Kzg2XMAQf_C1.jpg)