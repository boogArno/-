---
title: "LootFish"
description: "LootFish 是生活在 Avalanche C 链上的 10000 条美丽而奇异的鱼类的 NFT 集合."
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "lootfish.png"
tags: ["Collectibles","LootFish"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: "Avalanche"
website: "https://www.lootfish.co/"
twitter: "https://twitter.com/LootFishNFT"
discord: "https://discord.com/invite/K3KGeV7JfF"
telegram: "https://t.me/lootfish"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
LootFish 是 Avalanche C 链上的一个独特的 NFT 集合，包含 10000 条美丽而异国情调的鱼。该系列中有数百种外来鱼类，从彩虹鱼到垂钓者到倒钩。 LootFish 涵盖了海洋生物的整个范围，没有两个完全相同。抓鱼并烧掉它们以赚取 AVAX，或者在装饰精美的迷你水族馆中饲养它们！

![lootfish-dapp-collectibles-avalanche-image1_1457197c4c4095af91c4357f95478717](lootfish-dapp-collectibles-avalanche-image1_1457197c4c4095af91c4357f95478717.png)