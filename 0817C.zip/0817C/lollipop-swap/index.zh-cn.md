---
title: "Lollipop swap"
description: "棒棒糖金融新农业bsc"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "lollipop-swap.png"
tags: ["DeFi","Lollipop swap"]
categories: ["nfts"]
nfts: ["DeFi"]
blockchain: "BSC"
website: "https://www.lolli-pop.finance/"
twitter: "https://twitter.com/lollipopdefi"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
BSC农业棒棒糖财务

什么是棒棒糖 (LOL)？ 🍭

Lollipop 是第一个基于以太坊的流动性证明和权益证明的代币。这意味着供应被发送到 Uniswap 并提供了初始流动性。质押机制旨在奖励用户质押他们的棒棒糖。

![lollipopswap-dapp-defi-bsc-image1_9f356dcdc4a02d022d092030787ea98a](lollipopswap-dapp-defi-bsc-image1_9f356dcdc4a02d022d092030787ea98a.png)