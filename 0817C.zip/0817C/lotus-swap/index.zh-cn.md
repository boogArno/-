---
title: "Lotus Swap"
description: "币安智能链上的 DEFI 应用."
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "lotus-swap.png"
tags: ["DeFi","Lotus Swap"]
categories: ["nfts"]
nfts: ["DeFi"]
blockchain: "BSC"
website: "https://lotusswapdefi.com/"
twitter: "https://twitter.com/LotusSwap"
discord: ""
telegram: "https://t.me/lotusswapdefi"
github: "https://github.com/lotusswap"
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
什么是莲花交换？

Lotus Swap - 币安智能链 (BSC) 上的下一代 DeFi 交易所

币安智能链上的 DEFI 应用。

莲花交换统计
该数据代表被跟踪智能合约的原始链上活动

![lotusswap-dapp-defi-bsc-image2_8eededf40093e8da62f4b4b0f6231835](lotusswap-dapp-defi-bsc-image2_8eededf40093e8da62f4b4b0f6231835.png)