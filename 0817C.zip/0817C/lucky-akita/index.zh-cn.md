﻿---
title: "Lucky Akita"
description: "LUCKY AKITA ($LAKITA) 是一款以狗为主题的 meme 硬币，自称不是 meme 硬币，而是“一种新趋势"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "lucky-akita.png"
tags: ["Other","Lucky Akita"]
categories: ["nfts"]
nfts: ["Other"]
blockchain: "BSC"
website: "https://luckyakita.io/"
twitter: "https://twitter.com/LuckyAkitaCoins"
discord: ""
telegram: "https://t.me/luckyakitachannel"
github: ""
youtube: "https://www.youtube.com/channel/UCTLtddEuqWJAMuMpOyEFHjQ"
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
LUCKY AKITA ($LAKITA) 是一款以狗为主题的 meme 硬币，自称不是 meme 硬币，而是“一种新趋势”。这是一种由柴犬 (SHIB) 社区的粉丝和成员诞生的加密货币。这枚硬币以埃隆马斯克的柴犬命名。
$LAKITA 持有者将从交易费奖励中获得大量收益，并为全球受灾地区的慈善事业做出贡献

![luckyakita-dapp-games-bsc-image1_f6d4f947c74fc547eea1eb632d556b1a](luckyakita-dapp-games-bsc-image1_f6d4f947c74fc547eea1eb632d556b1a.png)