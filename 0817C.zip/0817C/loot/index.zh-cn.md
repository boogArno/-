---
title: "Loot"
description: "随机生成并存储在链上的冒险家装备"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "loot.png"
tags: ["Collectibles","Loot"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: "ETH"
website: "https://tv.apple.com/"
twitter: "https://twitter.com/lootproject"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
战利品是随机生成并存储在链上的冒险家装备。故意省略统计信息、图像和其他功能以供其他人解释。
随意以任何你想要的方式使用 Loot。

随机生成并存储在链上的冒险家装备。社区：http://lootproject.com/resources

![pGO0We31stheV4FJyc1eh](pGO0We31stheV4FJyc1eh.jpg)