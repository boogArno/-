---
title: "loomlocknft"
description: "物理遇上数字
是的。我们在做废话."
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "loomlocknft.png"
tags: ["Collectibles","loomlocknft"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: "ETH"
website: "https://loomlock.com/"
twitter: "https://twitter.com/loomlocknft"
discord: "https://discord.com/invite/loomlock"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
什么是织机？ loomlock 是一种物理锁定设备，旨在让您从成瘾和恶习中重新控制自己的生活。曾经想要锁定您的手机以将自己从社交媒体中拉出来，或者美味的款待正在盯着您，您知道您应该这样做没有？
它是如何工作的？您的 loomlock 带有一个内置计时器，在该计时器达到零之前，loomlock 将保持锁定状态。
我怎么得到一个？ loomlocks 将在未来空投给所有 loomlock NFT 持有者。loomlock 仍在积极开发中，但请稍后再回来查看更多更新！

![loomlocknft-dapp-collectibles-ethereum-image1_b418d28a50b003c633de01a8d10f5412](loomlocknft-dapp-collectibles-ethereum-image1_b418d28a50b003c633de01a8d10f5412.png)