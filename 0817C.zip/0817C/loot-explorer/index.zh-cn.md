﻿---
title: "Loot explorer"
description: "战利品：探索者是 8000 个独特的探索者角色，拥有自己独特的职业，配备基于第一个 8000 创世袋生成的战利品"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "loot-explorer.png"
tags: ["Collectibles","Loot explorer"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: "ETH"
website: "https://www.lootexplorers.quest/"
twitter: "https://twitter.com/lootexplorers"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
🎮    我们在做游戏吗？ 🗺️   有多少探险家可供铸造？ 🔳   我需要 Loot 来铸造 Explorer 吗？ 💰   薄荷的价格是多少？
战利品：探索者是 8000 个独特的探索者角色，拥有自己独特的职业，配备的战利品是根据前 8000 个创世袋战利品生成的。
Loot Explorers 项目的核心是有趣的艺术、社区和 RPG 风格的故事讲述与游戏灵感元素的融合。我们不仅仅专注于创建游戏或 PFP 艺术类型的项目，而是希望在 Loot 时间线内创建一个新世界。通过您自己的战利品袋可视化的战利品探索者世界！
如果您喜欢我们迄今为止为您设计的体验，请相信我们并继续关注我们接下来将为您打造的内容。
总供应量为 8003 个，但将有 8000 个 Explorers 可供铸造。额外的 3 个保留给团队（Kai、JH、Lunaa）。
不，你不需要 Loot 来铸造 Explorer。但是，OG Loot 持有者将获得“早期铸币”优先权，以首先铸币。

![lootexplorer-dapp-collectibles-ethereum-image1_9b0887f44215f400580d217a8f4cf473](ootexplorer-dapp-collectibles-ethereum-image1_9b0887f44215f400580d217a8f4cf473.png)