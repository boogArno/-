﻿---
title: "Loot Craft"
description: "LootCraft 是 bsc 上第一个受 Loot 和 LootRarity 启发的项目"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "loot-craft.png"
tags: ["NFT Games","Loot Craft"]
categories: ["nfts"]
nfts: ["NFT Games"]
blockchain: "BSC"
website: "https://lootcraft.io/"
twitter: "https://twitter.com/LootCraftNFT"
discord: ""
telegram: "https://t.me/LootCraftOffice"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
LootCraft 是 bsc 上第一个受 Loot 和 LootRarity 启发的项目。任何人都可以创建像 LootRarity 这样的召唤师，没有限制，不需要任何费用（除了 gas）。每天一次，召唤师可以冒险，赚取 250 经验值。一旦你获得了升级所需的经验值，你就可以升级。随着你的升级，你可以获得专

![1500x500](1500x500.jpg)长和法术位。