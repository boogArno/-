---
title: "LNSwap"
description: "支持闪电网络的堆栈和比特币之间的无信任原子交换交换"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "lnswap.png"
tags: ["DeFi","LNSwap"]
categories: ["nfts"]
nfts: ["DeFi"]
blockchain: "Stacks"
website: "https://dappradar.com/"
twitter: "https://twitter.com/ln_swap"
discord: "https://discord.gg/Gt45nMYPCM"
telegram: ""
github: "https://github.com/lnswap"
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
LNSwap 是一种原子交换交换，可实现比特币（链上和闪电网络）与包括 STX 在内的 Stacks 上的资产之间的无信任交换。
用户只需点击几下和 1 次确认即可从闪电网络上的比特币转到 Stacks，无需 KYC。
任何人都可以通过运行客户端应用程序并添加资金以加入 LNSwap 聚合器来提供流动性，并在用户完成的每次交换中赚取约 3% 的费用。支持闪电网络的堆栈和比特币之间的无信任原子交换交换

我们很高兴地宣布 已加入 Trust Machines 作为战略营销合作伙伴，以加速公司发展以及比特币应用程序的开发。

![1080x360](1080x360.jpg)