---
title: "LUCK TRON"
description: "LUCK TRON 是 TRON 区块链上的时间可扩展 DeFi 项目."
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "luck-tron.png"
tags: ["DeFi","LUCK TRON"]
categories: ["nfts"]
nfts: ["DeFi"]
blockchain: "TRON"
website: "https://lucktron.io/"
twitter: ""
discord: ""
telegram: "https://telegram.com/LuckTronOf"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
LUCK TRON 是 TRON 区块链上的一个时间可扩展的 DeFi 项目，它允许您质押 trx 并赚取 LUCK，这是 LUCK 生态系统的下一个 Dapp、Betluck、Luckbank 和 USDL（稳定币）的治理令牌。

幸运波场统计
该数据代表被跟踪智能合约的原始链上活动

![lucktron-dapp-defi-tron-image1_6bc80e4f5b5b0da168848ad6e97f1a73](lucktron-dapp-defi-tron-image1_6bc80e4f5b5b0da168848ad6e97f1a73.png)