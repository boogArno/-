---
title: "LOAGAME"
description: "P2E NFT 游戏
幻想龙世界
APR 高达 912%
联盟计划高达 12%
BUSD 奖励的每周和每月锦标赛"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "loagame.png"
tags: ["NFT Games","LOAGAME"]
categories: ["nfts"]
nfts: ["NFT Games"]
blockchain: "BSC"
website: "https://dappradar.com/"
twitter: "https://twitter.com/project_euro"
discord: ""
telegram: ""
github: ""
youtube: "https://www.youtube.com/channel/UCqqvZ9J_49LrSJKe7oKKZYw"
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
预售时间为 1 月 14 日下午 4 点 UTC
发布时间为 1 月 15 日下午 4 点 UTC
私人销售现已在 NFTLOA.COM 上进行
PLAY.NFTLOA.COM
代币合约地址 0xb16074cb791eba8c4100cce78656a4b34358399e
阿拉贡传奇是第一款 NFT Play to Earn web 3.0 冒险和战略游戏，由专门的 Beurop 团队开发，致力于不同的数字产品，用于创业和商业推广、教育和 Staking 平台以及其他旨在帮助用户获得加密知识的产品或/和赚钱。
游戏玩法
Grow you beat：3 种不同的类型 - 青铜、白银和黄金。
合并你的龙以提高他们的技能。
派他们去打猎 - 您将通过质押高达 912​​% 的年利率获得收益。
赢得每周和每月锦标赛并获得 LOAG 代币或/和 BUSD。
当您获得足够的收益时，您可以在 NFT 市场上出售您的最佳产品。
该游戏有一个会员计划，奖励高达 12%。邀请人并赚钱。您的 LOAG 代币奖励直接进入您的钱包，您可以在 PCS 上出售它们
玩赚模特
新玩家需要在 Marketplace 上购买 Beast 才能开始玩游戏。

![1080x360](1080x360.jpg)