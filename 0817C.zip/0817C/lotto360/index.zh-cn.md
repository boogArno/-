---
title: "Lotto360"
description: "Lotto360 是一款包含 Fruitland x100、Dice x8、Number of the Beast x25 游戏的赌博 dapp，币安智能链上安全可靠的 play2earn 游戏."
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "lotto360.png"
tags: ["Gambling","Lotto360"]
categories: ["nfts"]
nfts: ["Gambling"]
blockchain: "BSC"
website: "https://lotto360.io/"
twitter: "https://twitter.com/lotto360_io"
discord: ""
telegram: "https://t.me/lotto360_io"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/lotto360.io/"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Lotto360 是一个由 3 个 Play2Earn 游戏组成的赌博 dapp。
1- 骰子：买票并丢骰子，如果您猜对了数字，您将获得 x8 的赌注。
2- 野兽号：如果号码为 666，则购买彩票并在老虎机上旋转，您将获得 X25 的赌注。
3- Fruitland：买票并选择您的水果，如果您选择的水果与您赢得 X100 赌注的结果相符，则点击旋转。
所有游戏内随机数均由我们的服务器提供的链上区块属性和种子生成，以防止合约被黑客入侵，可安全玩。![lotto360-dapp-gambling-bsc-image1_c24e1536e20247288c9dae101846eecb](lotto360-dapp-gambling-bsc-image1_c24e1536e20247288c9dae101846eecb.png)