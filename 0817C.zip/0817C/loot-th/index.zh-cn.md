---
title: "Loot TH"
description: "受Loot启发，旨在发展基于泰国的游戏经济"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "loot-th.png"
tags: ["NFT Games","Loot TH"]
categories: ["nfts"]
nfts: ["NFT Games"]
blockchain: "ETH"
website: "https://opensea.io/"
twitter: "https://twitter.com/lootproject"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
拥有20多年经验的MMORPG游戏开发商旗下的开发项目。

Loot TH 是 Loot 的一个分叉项目，旨在探索带有 NFT 的 MMORPG 的可能性。 [战利品是随机生成并存储在链上的冒险家装备。故意省略统计信息、图像和其他功能，以供其他人解释。]

![lootth-dapp-games-ethereum-image1_c97cc666476842f8522665b62ad12529](lootth-dapp-games-ethereum-image1_c97cc666476842f8522665b62ad12529.png)