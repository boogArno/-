﻿---
title: "LOSTPOETS"
description: "从永恒"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "lostpoets.png"
tags: ["Collectibles","LOSTPOETS"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: "ETH"
website: "https://lostpoets.xyz/"
twitter: "https://twitter.com/poetslost"
discord: ""
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Lost Poets 是一款 NFT 收藏品和策略游戏。 NFT 集合包括 65536 个可获取的 NFT 和 1024 个 Origin NFT。该项目的发布分为几个阶段。有关详细信息，请参阅秘密路线图。
很久以前，在巴别图书馆，一个房间满是灰尘的书架上放着 65536 位诗人，他们都在等着被发现。在这个分形迷宫中，这些来自 1024 个不同起源的被遗忘的诗人在他们隐藏的 256 个自我之间漫游。![lostpoets-dapp-collectibles-ethereum-image1_5cd1cf97a156870820b24a64c3b0bd3e](lostpoets-dapp-collectibles-ethereum-image1_5cd1cf97a156870820b24a64c3b0bd3e.png)