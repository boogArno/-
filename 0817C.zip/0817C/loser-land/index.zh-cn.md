---
title: "Loser Land"
description: "Loser Land 是一款开放世界的回合制游戏。玩家可以在游戏中行走、建造、战斗和采矿."
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "loser-land.png"
tags: ["NFT Games","Loser Land"]
categories: ["nfts"]
nfts: ["NFT Games"]
blockchain: "OKC"
website: "https://www.loserland.org/"
twitter: "https://twitter.com/loser_coin"
discord: "https://discord.gg/hPz9VkShdX"
telegram: "https://t.me/loser_coin"
github: "https://github.com/losercoin"
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Loser Land是LoserCoin社区开发的一款2D开放世界回合制游戏。当前赛季是“鱿鱼游戏”，玩家可以互相攻击，在游戏结束时存活下来并分享池中的所有奖金。人们需要先购买一块土地来玩这个游戏，这在cherryswap中花费了两美元的鱿鱼。所有 $squid 都将累积在池中。进入游戏后，玩家可以在地图中四处走动，盖房子、鱼塘或矿井，与邻居打架，在游戏中挖/钓$鱿鱼。想开始旅程吗？保重，祝你们好运。下一季《向日葵农场》即将上线，敬请期待！

![loserlandsquidgame-dapp-games-okexchain-image1_e6a87130651776c4cc5e6087373e0ff1](loserlandsquidgame-dapp-games-okexchain-image1_e6a87130651776c4cc5e6087373e0ff1.png)