﻿---
title: "LOAD Network"
description: "LOAD 网络是以太坊区块链上的智能合约，根据价格预测的质量向 LOAD 代币储物柜提供红利。"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "load-network.png"
tags: ["DeFi","LOAD Network"]
categories: ["nfts"]
nfts: ["DeFi"]
blockchain: "ETH"
website: "https://dappradar.com/"
twitter: "https://twitter.com/LOAD_Network"
discord: "https://discord.gg/3MbUVjQMbq"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: "https://www.instagram.com/load.network_/"
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
LOAD 是一个基于以太坊的 De-Fi 项目，由致力于博弈论创新和 NFT 开发的全球专业加密爱好者团队于 2020 年 9 月推出。
该路线图列出了三个不同的阶段。第一阶段允许投资者铸造和分发代币，鼓励持有者锁定代币以获得每日股息排放的比例份额。
第一阶段对于赋予 LOAD 价值、提高认知度和采用率是必要的。
重点是在公平分配中推动大众采用。
真正的创新来自第二阶段。 LOAD 是第一个提供预测敏感兴趣的 De-Fi 平台。根据他们对 LOAD 价格储物柜的每日预测，如果他们是对的，他们总是会获得更多的利益，如果他们是错的，他们将获得更少的利益。他们永远不会赚到零。
已将代币锁定在智能合约中的储物柜或 LOAD 持有者在 LOAD 的方向上有两个选择。与预测错误的人相比，正确的储物柜将获得更大的利息份额。
我们正计划多个项目继续向 LOAD 储物柜提供加密红利，而不是在第二阶段启动之后（并且可能同时）推出通胀，以下是我们正在开展的项目列表（有关更多详细信息，请参阅下一页）：-一个加密货币预测平台（LOADCC）。 — 拥有自己代币的收益平台（LOADFI）（免费提供给 LOAD 储物柜）

- 连接到预测平台的集中式和分散式交易所（LOADEX）。 — 股票、民意调查和体育预测平台（LOADECO、SPORT&POLLS）。
LOAD 网络已经在 OpeaSea.io 市场上创建和分发了自己的稀有 NFT，其中 90% 的收益用于在 Uniswap 交易所回购 LOAD 代币。

![1080x360](1080x360.jpg)