---
title: "Longdrink Finance"
description: "longdrink.finance 在币安智能链上创建指数代币."
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "longdrink-finance.png"
tags: ["DeFi","Longdrink Finance"]
categories: ["nfts"]
nfts: ["DeFi"]
blockchain: "BSC"
website: "https://longdrink.finance/"
twitter: "https://twitter.com/LongdrinkDefi"
discord: "https://discord.gg/vKSrr2ZnQ6"
telegram: "https://t.me/longdrinkfinance"
github: "https://github.com/LongdrinkDefi/contracts"
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
longdrink.finance 在币安智能链上创建指数代币。因此，投资者可以轻松访问一套 Binance Smart Chain 代币。
LONG 是协议的治理代币，使持有者能够决定未来指数的组成及其权重，以及协议内的费用捕获。
第一个指数称为 BEV - 币安生态系统价值，由十个币安智能链蓝筹股（BNB、CAKE、BAKE、XVS、BCTST、TWT、SFP、EPS、ALPACA、NRV）组成。持有 BEV 意味着您持有上述所有代币的少量股份。![1_lKkts4VrU-X2KdqGS1X6rQ](1_lKkts4VrU-X2KdqGS1X6rQ.png)