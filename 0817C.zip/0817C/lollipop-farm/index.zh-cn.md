﻿---
title: "Lollipop.farm"
description: "Lollipop 是币安智能链上的 100% 去中心化多链农场和跨链桥接协议."
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "lollipop-farm.png"
tags: ["DeFi","Lollipop.farm"]
categories: ["nfts"]
nfts: ["DeFi"]
blockchain: "BSC"
website: "https://www.lollipop.farm/"
twitter: "https://twitter.com/FarmLollipop"
discord: ""
telegram: "https://t.me/LollipopfarmOfficial"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Lollipop 是币安智能链上的 100% 去中心化多链农场和跨链桥接协议。 Lollipop Bridge 建设完成后，Lollipop 协议将注入 100 万美元流动性作为初始流动性，其中 500,000 美元流动性在币安智能链上，另外 500,000 美元流动性在以太坊上。 Lollipop Bridge 将收取 0.5% 的费用作为团队的资金支持。

![1_4ecR3mtGCm_uYqE9X8WMyw](1_4ecR3mtGCm_uYqE9X8WMyw.jpeg)