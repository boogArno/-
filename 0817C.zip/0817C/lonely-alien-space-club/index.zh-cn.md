---
title: "Lonely Alien Space Club"
description: "10,001 个以编程方式生成的 ERC-721 NFT 代币"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "lonely-alien-space-club.png"
tags: ["Collectibles","Lonely Alien Space Club"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: "ETH"
website: "https://lonelyaliens.com/"
twitter: "https://twitter.com/thelonelyaliens"
discord: "https://discord.com/invite/thelonelyaliens"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
Lonely Alien Space Club 是存储在以太坊区块链上的 10,000 个独特的 ERC-721 代币的集合。每个 NFT 都是非连续铸造且可证明是独一无二的，都拥有完整的会员资格，包括功能实用的实用程序和不断发展的社区。该数据代表被跟踪智能合约的原始链上活动

![lonelyalienspaceclub-dapp-collectibles-ethereum-image2_1504752ace397684e7e3c6b614bbd4c4](lonelyalienspaceclub-dapp-collectibles-ethereum-image2_1504752ace397684e7e3c6b614bbd4c4.png)