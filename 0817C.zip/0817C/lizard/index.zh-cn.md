﻿---
title: "Lizard"
description: "Lizard Exchange 是 Oasis Emerald Paratime 中第一个提供全面交易分析、征税代币实施和 EIP 支持的 DEX"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
authors: ["Metabd"]
featuredImage: "lizard.png"
tags: ["Exchanges","Lizard"]
categories: ["nfts"]
nfts: ["Exchanges"]
blockchain: "Oasis Network"
website: "https://dappradar.com/"
twitter: "https://twitter.com/lizardexchange"
discord: ""
telegram: "https://t.me/lizardexchange"
github: "https://github.com/Lizard-Exchange/"
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: "https://lizardexchange.medium.com/"
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
由 Oasis 提供支持的 Oasis Emerald Paratime 和以太坊资产的社区驱动去中心化交易所，具有快速结算、低交易费用和民主分配的特点。 Lizard 为您带来最佳的交易机会，让您找到并最大化您的收益。
Lizard 是一个去中心化交易所，具有完整的交易所分析、征税代币实施和 EIP 支持，旨在欢迎新的建设者和用户。

Lizard Exchange 是 Oasis Emerald Paratime 中第一个提供全面交易分析、征税代币实施和 EIP 支持的 DEX

![1080x360](1080x360.jpg)