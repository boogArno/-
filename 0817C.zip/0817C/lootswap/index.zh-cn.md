---
title: "Lootswap"
description: "您的任务从 LootSwap 开始，这是一个关于和谐的多产品 DEX."
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "lootswap.png"
tags: ["Exchanges","Lootswap"]
categories: ["nfts"]
nfts: ["Exchanges"]
blockchain: "Harmony"
website: "https://lootswap.finance/"
twitter: ""
discord: "https://discord.gg/nz82UvJBpN"
telegram: "https://t.me/lootswap"
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---
LootSwap 是 Harmony 网络上的幻想游戏主题 DEX

一些骗子创建了一个假的 ONEFI 令牌。这是一个骗局。在任何情况下都不要购买。

OneFi 的官方代币尚未推出。一旦完成，我们将分享真实的合约地址。

与 8 月推出的假 MAGIC 代币一样，请避免使用这种假 ONEFI 代币。

![lootswap-dapp-exchanges-harmony-image1_d523c234eb49959d6cd63d2e02af8088](lootswap-dapp-exchanges-harmony-image1_d523c234eb49959d6cd63d2e02af8088.png)