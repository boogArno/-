﻿---
title: "Lives of Asuna"
description: "通过 Zumi 和 Hagglefish 手绘的动漫风格 NFT 合集，一睹 Asuna 的 10,000 条独特的生活。"
date: 2022-08-17T00:00:00+08:00
lastmod: 2022-08-17T00:00:00+08:00
draft: false
authors: ["boogArno"]
featuredImage: "lives-of-asuna.png"
tags: ["Collectibles","Lives of Asuna"]
categories: ["nfts"]
nfts: ["Collectibles"]
blockchain: "ETH"
website: "https://dappradar.com/"
twitter: "https://twitter.com/LivesOfAsuna"
discord: "https://discord.com/invite/livesofasuna"
telegram: ""
github: ""
youtube: ""
twitch: ""
facebook: ""
instagram: ""
reddit: ""
medium: ""
steam: ""
gitbook: ""
googleplay: ""
appstore: ""
status: "Live"
weight: 
lightgallery: true
toc: true
pinned: false
recommend: false
recommend1: false
---

HTML






自定义亚丝娜并塑造她的故事另一个生活中的成功偶像
从一个恶魔领主的一生...
...对于另一个机甲飞行员来说，《亚丝娜的生活》是由 ZumiDraws 构思和设计的一个系列，它探索了我们的名义角色的许多生活，因为她存在于广阔的多元宇宙中。
每个 Asuna NFT 总计 10,000 个，是受丰富的动漫世界启发的独特特征组合，从科幻和幻想到生活片段。
亚丝娜 NFT 可以根据您的想象进行定制和塑造，并使用特殊物品来改变她的外观。 这些物品将在首次发布后发布并可以交易。
亚丝娜可以做到这一切——包括作为跨越多元宇宙的音乐家的生活。 聆听亚丝娜的音乐会启发您的亚丝娜生活是多么富有想象力。 无尽的可能性和故事等待着。 亚丝娜的第一首曲子会在合集发售前发售



![1080x360](1080x360.jpg)